# -*- coding: utf-8 -*-
"""컨슈머 하나로 받아 스레드로 나눠 주는 펌프.

임베딩에서 먼저 만든 것을 ETL·청킹에도 쓴다. 세 워커에 같은 코드를 세 벌
두면 오프셋 커밋처럼 틀리기 쉬운 것이 세 군데서 따로 썩는다.

컨슈머는 파드당 하나만 둔다. Kafka 는 파티션 수까지만 컨슈머를 붙일 수 있어,
컨슈머를 늘리는 것으로는 파티션 수를 넘지 못한다. 하나로 받아 스레드에 나눠
주면 그 제약을 넘는다.

커밋은 **빈틈없이 이어진 앞부분까지만** 한다(OffsetTracker). 10·12 가 끝나고
11 이 진행 중이면 10 까지만 올린다. 중간에 죽으면 11·12 를 다시 받는다 —
중복은 나지만 유실은 없다.

**기본값은 셋 다 1 이고, 운영 파드에서도 1 로 둔다.** 현장 파드가 1코어
2기가다. 코어가 하나면 스레드를 늘려도 번갈아 돌 뿐이고, 대기열에 든 것은
모두 아직 커밋되지 않은 오프셋이라 파드가 죽었을 때 다시 받는 양만 늘어난다.
처리량이 모자라면 replicas 를 늘린다.

**기본값은 셋 다 1 이고, 현장 파드에서도 1 로 둔다.** 파드가 1코어 2기가다.
코어가 하나면 스레드를 늘려도 번갈아 돌 뿐이고, 대기열에 든 것은 모두 아직
커밋되지 않은 오프셋이라 파드가 죽었을 때 다시 받는 양만 늘어난다. 처리량이
모자라면 replicas 를 늘린다.

실측(워커 로그 타임스탬프 기준, 측정 비용 0):

  ETL 300건      1스레드 101건/s → 8스레드 146건/s  (1.45배)
  임베딩 만 건    1스레드  81건/s → 8스레드 555, 16스레드 999
                 (임베딩 호출은 스텁. 펌프와 커밋 경로만 본 값이다)

ETL 의 건당 비용은 처리 11.5ms + 커밋 4.1ms 다. 초당 백 건을 넘으므로 대량
인제스트에서 ETL 이 병목이 되는 일은 없다. 스레드를 늘려도 1.45배에 그치는
것은 컨슈머가 파드당 하나이고 커밋도 poll 하는 스레드가 하기 때문이다 —
처리 쪽을 늘려도 그 한 줄은 넓어지지 않는다.

임베딩은 다르다. 하는 일이 거의 외부 임베딩 서버 응답 대기라 한 건당 수백
ms 를 기다리고, 그 대기가 겹치면 컨슈머 경로의 비용을 덮는다. 코어를 늘린
파드에서 올려 볼 값이 있는 것은 임베딩뿐이다.

측정에 주의할 것이 있다. lag 을 물어 재면 조회마다 컨슈머를 새로 만들어
호출당 1~2초가 들고, 그것이 워커 처리량으로 오해된다(그 방식으로 4.8건/s 가
나왔다). 첫 poll 은 컨슈머 그룹 가입을 기다려 3초가 걸리므로 평균에 섞으면
안 된다. 워커 로그의 시각을 쓰고, LOG_FORMAT 에 밀리초를 넣는다.
"""
from __future__ import annotations

import threading
import time
from concurrent.futures import ThreadPoolExecutor
from typing import Any, Callable, Dict, Optional

from loguru import logger

from rag_common.concurrency import OffsetTracker, resolve_concurrency


class MessagePump:
    """메시지를 받아 처리하고 커밋한다.

    :param handler: ``(message_id, data)`` 를 받아 한 건을 끝까지 처리한다.
                    ack 는 펌프가 한다 — 처리 쪽이 커밋 시점을 정하면 스레드로
                    돌릴 때 틀린다
    :param threads: 1 이면 받은 자리에서 한 건씩(기존 동작)
    :param queue_factor: 대기열 깊이 = threads × 이 값. 큐에 든 것은 모두 아직
                         커밋되지 않은 오프셋이라, 깊게 둘수록 파드가 죽었을 때
                         다시 받는 양만 늘어난다
    :param before_read: 매번 받기 전에 묻는다. True 를 돌려주면 그 회차는 쉰다
                        (청킹의 역압이 이것을 쓴다)
    """

    def __init__(self, broker, stream: str, group: str, consumer: str,
                 handler: Callable[[str, Dict[str, Any]], None],
                 threads: int = 1, queue_factor: int = 2,
                 poll_timeout_sec: float = 5.0,
                 before_read: Optional[Callable[[], bool]] = None,
                 label: str = "워커"):
        self.broker = broker
        self.stream = stream
        self.group = group
        self.consumer = consumer
        self.handler = handler
        self.poll_timeout_sec = poll_timeout_sec
        self.before_read = before_read
        self.label = label

        # 수신이 터졌을 때 쉬는 시간. 터지자마자 다시 물으면 로그가 넘친다.
        self.error_sleep_sec = 1.0

        self.threads = max(1, int(threads))
        self.queue_limit = self.threads * max(1, int(queue_factor))
        self._tracker = OffsetTracker()
        self._pool: Optional[ThreadPoolExecutor] = None
        self._slots: Optional[threading.Semaphore] = None

        # 커밋해도 되는 것을 여기 적어 두고, poll 하는 스레드가 가져가 커밋한다.
        #
        # 워커 스레드에서 commit(asynchronous=False) 을 부르면 영구히 멈춘다.
        # 메인 스레드가 poll() 안에 있는 동안 컨슈머 큐가 서비스되지 않아 커밋
        # 응답을 기다리다 서는 것이다. ETL 이 16건 처리 후 멈춘 실제 스택:
        #
        #   Thread ETL_0:     ack (message_broker.py)   ← commit 에서 멈춤
        #   Thread ETL_1..3:  work (worker_pump.py)     ← 커밋 잠금 대기
        self._pending_lock = threading.Lock()
        self._pending: list = []

    @classmethod
    def from_env(cls, threads_var: str, factor_var: str, **kwargs) -> "MessagePump":
        """스레드 수를 설정 파일이나 환경변수에서 읽는다.

        오타가 나도 1 로 떨어진다. 한 건씩 처리하는 기존 동작이다.
        """
        from rag_common.config import get_setting
        threads = resolve_concurrency(get_setting(threads_var))
        factor = resolve_concurrency(get_setting(factor_var) or "2")
        return cls(threads=threads, queue_factor=factor, **kwargs)

    # ----- 내부 -----

    def _ack(self, message_id: str) -> None:
        self.broker.ack(self.stream, self.group, message_id)

    def _queue_ack(self, message_id: str) -> None:
        """커밋해도 되는 것을 적어 둔다. 워커 스레드에서 부른다."""
        with self._pending_lock:
            self._pending.append(message_id)

    def _flush_acks(self) -> None:
        """적어 둔 것을 커밋한다. **poll 하는 스레드에서만** 부른다."""
        with self._pending_lock:
            if not self._pending:
                return
            batch, self._pending = self._pending, []
        for message_id in batch:
            try:
                self._ack(message_id)
            except Exception as e:
                # 커밋 실패로 워커를 세우지 않는다. 다음 기동에 다시 받는다 —
                # 중복은 나지만 유실은 없다.
                logger.error(f"{self.label} 커밋 실패: id={message_id}, error={e}")

    def _handle_and_ack(self, message_id: str, data: Dict[str, Any]) -> None:
        """받은 자리에서 한 건. 스레드를 쓰지 않을 때의 기존 동작."""
        try:
            self.handler(message_id, data)
        except Exception as e:
            # 결과 통지는 처리 쪽에서 이미 했다. 여기까지 온 것은 통지조차 못
            # 한 경우라, 오프셋을 올려 같은 건을 무한히 돌지 않게 한다.
            logger.error(f"{self.label} 처리 실패(오프셋은 올림): "
                         f"id={message_id}, error={e}")
        self._ack(message_id)

    def _dispatch_individual(self, message_id: str, data: Dict[str, Any]) -> None:
        """끝난 것을 하나씩 ack 한다. ack 가 누적이 아닌 브로커(Redis)용.

        Redis 의 XACK 는 건별이라 이어진 앞부분만 올리면 나머지가 PEL 에
        영구히 남는다. 반대로 건별이면 순서를 맞출 필요가 없다 — 끝나는
        대로 ack 하면 된다.
        """
        self._slots.acquire()

        def work():
            try:
                self.handler(message_id, data)
            except Exception as e:
                logger.error(f"{self.label} 처리 실패(ack 는 함): "
                             f"id={message_id}, error={e}")
            finally:
                # 커밋은 poll 하는 스레드가 한다. 여기서 부르면 멈춘다.
                self._queue_ack(message_id)
                self._slots.release()

        self._pool.submit(work)

    def _dispatch(self, message_id: str, data: Dict[str, Any]) -> None:
        if not getattr(self.broker, "cumulative_ack", False):
            self._dispatch_individual(message_id, data)
            return

        parsed = OffsetTracker.parse_id(message_id)
        if parsed is None:
            # 오프셋을 셀 수 없는 id. 순서를 지킬 수 없으니 받은 자리에서.
            self._handle_and_ack(message_id, data)
            return

        partition, offset = parsed
        # 빈 자리가 날 때까지 여기서 선다. 되묻지 않고 기다리는 것이 중요하다 —
        # 깨어나는 간격만큼 처리량이 깎인다. 만 건을 8스레드로 돌렸을 때
        # 0.05초마다 되물으니 278건/s, 기다리게 하니 555건/s 였다.
        self._slots.acquire()
        self._tracker.started(partition, offset)

        def work():
            try:
                self.handler(message_id, data)
            except Exception as e:
                logger.error(f"{self.label} 처리 실패(오프셋은 올림): "
                             f"id={message_id}, error={e}")
            finally:
                try:
                    for p, o in self._tracker.done(partition, offset).items():
                        # 커밋은 poll 하는 스레드가 한다. 여기서 부르면 멈춘다.
                        self._queue_ack(f"{p}-{o}")
                finally:
                    # 적어 두는 데 실패해도 자리는 돌려준다. 안 그러면 펌프가 선다.
                    self._slots.release()

        self._pool.submit(work)

    # ----- 실행 -----

    def run(self) -> None:
        """KeyboardInterrupt 가 올 때까지 돈다."""
        if self.threads > 1:
            self._slots = threading.Semaphore(self.queue_limit)
            self._pool = ThreadPoolExecutor(max_workers=self.threads,
                                            thread_name_prefix=self.label)
            logger.info(
                f"{self.label} 동시 처리: 스레드={self.threads}, "
                f"대기열 상한={self.queue_limit} "
                f"(완료된 오프셋은 빈틈없이 이어진 데까지만 커밋합니다)")
        else:
            logger.info(f"{self.label} 동시 처리 사용 안 함 (스레드=1)")

        while True:
            try:
                # 끝난 건의 커밋을 여기서 한다. 워커 스레드에서 하면 멈춘다.
                self._flush_acks()

                if self.before_read is not None and self.before_read():
                    continue

                message = self.broker.read_message(
                    self.stream, self.group, self.consumer,
                    timeout_ms=int(self.poll_timeout_sec * 1000),
                )
                if not message:
                    continue

                message_id, data = message
                if self._pool is None:
                    self._handle_and_ack(message_id, data)
                else:
                    self._dispatch(message_id, data)

            except KeyboardInterrupt:
                logger.info(f"{self.label} 종료 요청")
                break
            except Exception as e:
                logger.error(f"{self.label} 실행 중 오류: {e}", exc_info=True)
                if self.error_sleep_sec:
                    time.sleep(self.error_sleep_sec)

        if self._pool is not None:
            # 처리 중인 건을 끝내고 커밋까지 마치게 한다. 기다리지 않으면
            # 호출자가 broker.close() 로 넘어가, 닫힌 컨슈머에 commit 을 하다
            # 터지거나(만 건 로드 테스트에서 segfault 확인) 마친 것을 안 끝난
            # 것으로 만들어 다시 받는다.
            logger.info(f"{self.label}: 처리 중인 건이 끝나기를 기다립니다...")
            self._pool.shutdown(wait=True)

        # 남은 커밋을 마친다. 안 하면 마친 건을 다음 기동에 다시 받는다.
        # 여전히 메인 스레드이고 poll 은 끝났으므로 여기서 해도 안전하다.
        self._flush_acks()

        logger.info(f"{self.label} 종료")
