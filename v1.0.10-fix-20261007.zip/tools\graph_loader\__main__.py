# -*- coding: utf-8 -*-
"""범용 오프라인 적재기 — 웹 수집/덤프 → 선별 → 그래프.

    python -m graph_loader fetch   --rss <피드URL> | --urls urls.txt   # 크롤링(선택)

    python -m graph_loader parse   --blog blog.json --messenger msgs.json
    python -m graph_loader extract
    python -m graph_loader select
    python -m graph_loader store   [--reset]
    python -m graph_loader report
    python -m graph_loader all     --blog … --messenger … [--reset]

## 워커·Kafka 없이 간다

PoC 는 덤프를 한 번에 넣는다. 제품의 자동 색인 경로(워커→Kafka→엔진 컨슈머)가
할 일을 이 툴이 in-process 로 한다 — 추출·정합은 **같은 엔진 코어**라 제품과
다르지 않다. 질의는 엔진 REST + 서버가 한다.

## 단계를 나누고 문서마다 남긴다

`work/extracted/<doc>.json` 이 있으면 그 문서의 추출은 건너뛴다 — LLM 추출이
가장 비싸고 가장 자주 끊긴다. 다시 돌리려면 파일을 지운다.

## loader_lab 을 재사용한다

LLM·팩·전략·파라미터·그래프 호스트는 `loader_lab` 의 것을 그대로 쓴다. 두 벌이
되면 결속 검사나 저장 속성이 미묘하게 갈리고, 그 차이는 질의가 빈 결과를 낼
때에야 드러난다.
"""
from __future__ import annotations

import argparse
import asyncio
import json
import os
import pathlib
import sys
import time
from types import SimpleNamespace

HERE = pathlib.Path(__file__).resolve().parent
ENGINE = HERE.parents[1]
sys.path.insert(0, str(HERE.parent))

from loader_lab import __main__ as lab  # noqa: E402  — 헬퍼 재사용
from graph_loader.hosts import make_host as _host  # noqa: E402

import console_safe  # 콘솔 인코딩으로 죽지 않게 - cp949 에 없는 글자는 '?' 로
console_safe.enable()



# ── 작업 폴더 ───────────────────────────────────────────────
def _docs_path(work: pathlib.Path) -> pathlib.Path:
    return work / "docs.json"


def _stage_dir(work: pathlib.Path, stage: str) -> pathlib.Path:
    path = work / stage
    path.mkdir(parents=True, exist_ok=True)
    return path


def _doc_file(work: pathlib.Path, stage: str, doc_id: str) -> pathlib.Path:
    return _stage_dir(work, stage) / (doc_id.replace(":", "__") + ".json")


def _load_docs(work: pathlib.Path):
    from graph_loader.source import SourceDoc

    path = _docs_path(work)
    if not path.is_file():
        raise SystemExit(f"{path} 가 없습니다. 먼저 `parse` 를 돌리십시오.")
    return [SourceDoc.from_dict(d) for d in
            json.loads(path.read_text(encoding="utf-8"))]


def _write(path: pathlib.Path, payload) -> None:
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2),
                    encoding="utf-8")


def _read(path: pathlib.Path):
    return json.loads(path.read_text(encoding="utf-8"))


# ── 단계 ────────────────────────────────────────────────────
def step_fetch(args) -> None:
    """웹 수집 — RSS/Atom 피드 또는 URL 목록 → blog.json (fetch.py)."""
    from graph_loader.fetch import fetch_rss, fetch_urls

    out = args.work / "crawl"
    if args.rss:
        posts = fetch_rss(args.rss, max_posts=args.fetch_posts,
                          min_chars=args.fetch_min_chars, out=out)
    elif args.urls:
        url_list = [u.strip() for u in
                    pathlib.Path(args.urls).read_text(encoding="utf-8").splitlines()
                    if u.strip() and not u.strip().startswith("#")]
        posts = fetch_urls(url_list, min_chars=args.fetch_min_chars, out=out)
    else:
        raise SystemExit("fetch 에는 --rss <피드URL> 또는 --urls <파일> 이 필요합니다")
    print(f"수집 {posts}건 → {out / 'blog.json'} — parse 는 --blog 로 이 파일을 받는다")


def step_parse(args) -> None:
    from graph_loader.source import load_blog, load_messenger

    docs = []
    if args.blog:
        blog = load_blog(pathlib.Path(args.blog), max_chars=args.chunk_chars)
        print(f"블로그 글 {len(blog)}개")
        docs.extend(blog)
    if args.messenger:
        msgs = load_messenger(pathlib.Path(args.messenger),
                              max_chars=args.chunk_chars,
                              gap_minutes=args.gap_minutes)
        print(f"메신저 스레드 {len(msgs)}개")
        docs.extend(msgs)
    if not docs:
        raise SystemExit("--blog 또는 --messenger 가 필요합니다")

    args.work.mkdir(parents=True, exist_ok=True)
    _write(_docs_path(args.work), [d.as_dict() for d in docs])
    chunks = sum(len(d.chunks) for d in docs)
    chars = sum(len(c["text"]) for d in docs for c in d.chunks)
    print(f"문서 {len(docs)}개, 청크 {chunks}개, 본문 {chars:,}자 → {_docs_path(args.work)}")
    for doc in docs[:5]:
        print(f"  {doc.doc_id} [{doc.kind}] {doc.title[:40]!r} 청크 {len(doc.chunks)}")


async def step_extract(args) -> None:
    from omni_adapters.runtime.pool import AdapterRuntime
    from ontology_engine.core.contract import Chunk, EngineTask
    from ontology_engine.core.pipeline import run_extraction

    docs = _load_docs(args.work)
    pack = lab._pack(args)
    strategy, mode, llm_concepts = lab._strategy(args, None)
    print(f"  전략: {args.strategy} → mode={mode}, llm_concept={llm_concepts}")

    # 문서를 몇 개씩 동시에 돌리나. `--concurrency` 는 **한 문서 안의 프롬프트
    # 묶음**에만 걸려서, 문서가 짧아 묶음이 1개면 아무 효과가 없다 — 현장에서
    # 동시성 8 을 줬는데도 추출이 한 건씩 올라간 것이 그래서다(2026-10-01).
    # 기본 1 은 지금까지의 동작이다. 올리면 LLM 호출이 **문서 동시 × 묶음 동시**가
    # 되므로 사내 LLM 이 받는 만큼만 올린다.
    doc_limit = max(1, getattr(args, "doc_concurrency", 1))
    # 실패한 문서를 몇 번 더 시도하나. 사내 LLM 이 일시적으로 400 을 뱉고 같은
    # 요청이 다음에는 통하는 일이 있다(2026-10-02 현장). 수 시간짜리 적재에서
    # 사람이 다시 돌리게 하지 않고 여기서 한 번 더 한다 — **같은 요청을 같은
    # 대상에** 보내는 것이므로 폴백이 아니다(ONT-01 §4-8).
    retries = max(0, getattr(args, "extract_retries", 1))

    runtime = AdapterRuntime()
    semaphore = asyncio.Semaphore(doc_limit)
    #: doc_id → 마지막 실패 이유. 끝에 **무엇이 왜 빠졌는지** 말해야 한다.
    reasons: dict[str, str] = {}
    #: doc_id → 온전하지 않은데 개념만 살린 사유. 유실 규모를 끝에 말해야 한다.
    salvaged: dict[str, str] = {}
    try:
        llm = lab._llm(args, runtime) if mode != "NLP_ONLY" or llm_concepts else None

        for attempt in range(retries + 1):
            # 매 패스마다 다시 센다 — 앞 패스가 성공시킨 것은 빠진다.
            todo = [d for d in docs
                    if not _doc_file(args.work, "extracted", d.doc_id).is_file()]
            if not todo:
                break
            if attempt == 0:
                print(f"  문서 {len(docs)}개 중 {len(todo)}개 추출 (나머지는 이미 있음)"
                      f" — 문서 동시 {doc_limit} / 묶음 동시 {args.concurrency}")
            else:
                print()
                print(f"재시도 {attempt}/{retries} — 못 한 {len(todo)}건을 "
                      f"다시 시도합니다")
            total = len(todo)
            done = 0
            # 마지막 패스인가. 여기서는 더 나아질 기회가 없으므로 **쓸 것이 있으면
            # 살린다**(아래 `keep`).
            last_pass = attempt == retries

            async def extract_one(doc) -> None:
                nonlocal done
                chunks = [Chunk(**c) for c in doc.chunks]
                task = EngineTask(doc_id=doc.doc_id, pack=args.pack,
                                  params=lab._params(args, mode, llm_concepts),
                                  chunks=chunks)
                async with semaphore:
                    started = time.perf_counter()
                    result = await run_extraction(task, pack=pack,
                                                  strategy=strategy, llm=llm,
                                                  embedding=None)
                    elapsed = time.perf_counter() - started
                # **실패는 `extracted/` 에 쓰지 않는다.** 거기 있으면 다음 실행이
                # "이미 했음" 으로 건너뛴다 - 사내 LLM 이 일시적으로 400 을 뱉은
                # 문서가 영구히 빠졌다(2026-10-02 현장). 진단할 내용은 `failed/`
                # 에 남긴다 - 지우면 무엇이 왜 실패했는지 알 수 없다.
                ok = result.status == "success"
                # **마지막 패스에서는 개념이 있으면 살린다.**
                #
                # `partial` 은 "쓸 건 나왔지만 온전하지 않다" 다. 현장에서 가장 흔한
                # 사유는 관계 추출의 본문 상한이었다 - 개념 9 개를 뽑고 관계만 0 인
                # 문서가 `failed/` 로 가서 **개념까지 통째로 버려졌다**(2026-10-06).
                # 개념층의 관계는 업무 그래프 위의 보조축이고, 개념이 없으면 그
                # 문서는 그래프에 아예 존재하지 않는다 - 잃는 크기가 다르다.
                #
                # 재시도 기회는 그대로다: 중간 패스에서는 `failed/` 에 두어 다시
                # 시도하고, 더 나아질 기회가 없을 때만 살린다.
                # `error` 는 살리지 않는다 - 배치 실패율이 임계치를 넘었거나
                # 고른 방식이 실행되지 못한 것이고, 그 결과는 믿을 수 없다.
                keep = ok or (last_pass and result.status == "partial"
                              and bool(result.concepts))
                _write(_doc_file(args.work, "extracted" if keep else "failed",
                                 doc.doc_id),
                       json.loads(result.model_dump_json()))
                done += 1
                if ok:
                    flag = ""
                elif keep:
                    # 살렸다는 사실과 무엇을 잃었는지 같이 말한다.
                    flag = f"  ← {result.status} (개념만 살림, 관계 유실)"
                else:
                    flag = f"  ← {result.status}"
                # 동시로 돌면 완료 순서가 입력 순서와 다르다 — 번호는 '끝난 수' 다.
                print(f"[{done}/{total}] {doc.doc_id}: 개념 {len(result.concepts)} "
                      f"관계 {len(result.relations)} {elapsed:.0f}초{flag}")
                if ok:
                    reasons.pop(doc.doc_id, None)
                    salvaged.pop(doc.doc_id, None)
                else:
                    reasons[doc.doc_id] = (result.error_message
                                           or result.status or "이유 없음")
                    if keep:
                        # 살린 것도 **규모를 알아야** 한다. 관계 유실이 얼마나
                        # 되는지 모르면 그래프 품질을 오판한다.
                        salvaged[doc.doc_id] = (
                            "; ".join(result.stats.notes[:2])
                            or result.error_message or result.status)
                    if result.error_message:
                        print(f"      {result.error_message}")
                lab._print_stats(result.stats)

            # 예외는 그대로 올린다 — 첫 실패에서 멈추고, 끝난 문서는 extracted/ 에
            # 남아 다음 실행이 건너뛴다(이어하기).
            await asyncio.gather(*(extract_one(doc) for doc in todo))
    finally:
        runtime.sync_close()

    # **끝에 무엇이 빠졌는지 말한다.** 건너뛴 것을 세지 않으면 그래프가 왜
    # 비어 보이는지 알 수 없고, 빠진 문서를 모른 채 질의 결과를 믿게 된다.
    missing = [d.doc_id for d in docs
               if not _doc_file(args.work, "extracted", d.doc_id).is_file()]
    if missing:
        print()
        print(f"{'=' * 60}")
        print(f"추출하지 못한 문서 {len(missing)}건 / 전체 {len(docs)}건"
              f"  (재시도 {retries}회까지 했습니다)")
        for doc_id in missing[:10]:
            print(f"  - {doc_id}: {reasons.get(doc_id, '이유 미기록')}")
        if len(missing) > 10:
            print(f"  ... 그리고 {len(missing) - 10}건 더")
        print(f"  자세한 내용은 {_stage_dir(args.work, 'failed')} 에 있습니다.")

    # 살린 문서도 말한다 — 개념은 들어갔지만 관계가 비었다는 사실을 모르면
    # "관계가 왜 이렇게 적나" 를 그래프 쪽에서 찾게 된다.
    if salvaged:
        print()
        print(f"개념만 살린 문서 {len(salvaged)}건 / 전체 {len(docs)}건"
              f" — 관계가 유실됐습니다")
        for doc_id in list(salvaged)[:5]:
            print(f"  - {doc_id}: {salvaged[doc_id]}")
        if len(salvaged) > 5:
            print(f"  ... 그리고 {len(salvaged) - 5}건 더")
        print("  관계만 다시 뽑으려면 개념을 재사용하십시오 "
              "(tools/rerun_relations.py) — 개념 추출을 다시 하지 않아도 됩니다.")
        print("  다시 돌리면 이 문서만 재시도합니다(성공한 것은 건너뜁니다).")
        print('=' * 60)
    else:
        print()
        print(f"문서 {len(docs)}건 모두 추출됨 — 빠진 것 없습니다")


def step_select(args) -> None:
    from graph_loader.select import derive_discussed, select_for_graph
    from ontology_engine.core.contract import EngineResult

    docs = _load_docs(args.work)
    pack = lab._pack(args)
    fallback_types = {t.code for t in pack.concept_types if getattr(t, "fallback", False)}
    anchor_types = {a.strip() for a in args.anchor_types.split(",") if a.strip()}
    unknown = anchor_types - {t.code for t in pack.concept_types}
    if unknown:
        raise SystemExit(f"앵커 타입이 팩에 없습니다: {sorted(unknown)}")
    print(f"  폴백 타입 {sorted(fallback_types)} 제외, 앵커 {sorted(anchor_types)}")

    summary = []
    for doc in docs:
        src = _doc_file(args.work, "extracted", doc.doc_id)
        if not src.is_file():
            print(f"  {doc.doc_id}: 추출 결과 없음 — 건너뜀 (extract 먼저)")
            continue
        result = EngineResult(**_read(src))
        concepts, relations, stats = select_for_graph(
            result.concepts, result.relations,
            fallback_types=fallback_types, anchor_types=anchor_types)
        persons, discussed = derive_discussed(
            doc.author if doc.kind == "blog" else "", concepts,
            target_types=anchor_types,
            doc_chunk_ids={c["chunk_id"] for c in doc.chunks})
        result.concepts = concepts + persons
        result.relations = relations + discussed
        payload = json.loads(result.model_dump_json())
        payload["selection"] = stats.as_dict()
        payload["discussed"] = len(discussed)
        _write(_doc_file(args.work, "selected", doc.doc_id), payload)

        note = ""
        if stats.concepts_in and stats.anchors_found == 0:
            note = "  ← 앵커 0: 잡담이면 정상, 설비 얘기면 추출 누락"
        print(f"  {doc.doc_id}: {stats.concepts_in}→{stats.concepts_out} 개념 "
              f"(폴백 -{stats.dropped_fallback}, 비앵커 -{stats.dropped_unanchored}), "
              f"{stats.relations_in}→{stats.relations_out} 관계, "
              f"discussed +{len(discussed)}{note}")
        summary.append({"doc_id": doc.doc_id, **stats.as_dict(),
                        "discussed": len(discussed)})
    _write(args.work / "selection.json", summary)


def drop_blank_canonical(concepts, relations):
    """빈 canonical 개념과 그것을 가리키는 관계를 걸러낸다.

    빈 canonical 이 ArangoDB 까지 가면 `_key` 가 비어 `[ERR 1221] illegal
    document key` 로 **적재 전체가 멈춘다**(2026-10-02 현장). 키를 만드는
    자리에서도 막지만, 거기서 막으면 여전히 멈춘다 — 빈 개념 한 건 때문에
    수천 건이 못 들어가는 것은 과하다.

    정합을 거친 개념은 그래프에서 읽은 값으로 canonical 이 바뀔 수 있어,
    계약(`Concept.canonical`)의 검증을 통과한 뒤에도 빌 수 있다.

    버린 개념을 가리키는 관계를 남기면 없는 노드로 가는 간선이 된다.

    돌려주는 것: (남은 개념, 남은 관계, 버린 개념 수)
    """
    kept = [c for c in concepts if (c.canonical or "").strip()]
    if len(kept) == len(concepts):
        return concepts, relations, 0
    names = {c.canonical for c in kept}
    kept_relations = [r for r in relations
                      if (r.src or "").strip() and (r.dst or "").strip()
                      and r.src in names and r.dst in names]
    return kept, kept_relations, len(concepts) - len(kept)


async def step_store(args) -> None:
    from omni_adapters.runtime.pool import AdapterRuntime
    from ontology_engine.core.contract import EngineResult
    from ontology_engine.core.resolve import ResolveParams, resolve_against_graph

    docs = _load_docs(args.work)
    pack = lab._pack(args)
    host = _host(args)
    runtime = AdapterRuntime()
    # 실패 경로가 쓰는 값은 try 밖에서 정한다. 첫 문서 전에 죽으면(접속 불가·팩 결속 등)
    # except 의 안내문이 UnboundLocalError 로 덮여 **진짜 원인이 사라진다**(2026-09-17 실측).
    done = 0
    try:
        if args.reset:
            # reset 은 결속을 덮는 것이 의도다(require_pack 의 안내가 그렇다) —
            # 대신 **무엇을 지우는지** 찍는다. 다른 팩의 인덱스를 말없이 지우지 않게.
            bound = host.bound_pack()
            print(f"  인덱스 '{args.index}' (팩 {bound or '없음'}) 를 비웁니다")
            host.reset()
        host.require_pack(args.pack)
        embedding = lab._embedding(args, runtime) if args.resolve_embedding else None

        total_nodes = total_edges = 0
        limit_hits = 0
        total_blank = 0
        store_failures: list[tuple[str, str]] = []
        for n, doc in enumerate(docs, 1):
            src = _doc_file(args.work, "selected", doc.doc_id)
            if not src.is_file():
                print(f"[{n}/{len(docs)}] {doc.doc_id}: 선별 결과 없음 — 건너뜀")
                continue
            if _doc_file(args.work, "stored", doc.doc_id).is_file() and not args.reset:
                print(f"[{n}/{len(docs)}] {doc.doc_id}: 이미 저장됨 — 건너뜀 (stored/ 삭제 시 재저장)")
                continue
            result = EngineResult(**{k: v for k, v in _read(src).items()
                                     if k not in ("selection", "discussed")})
            if not result.concepts:
                print(f"[{n}/{len(docs)}] {doc.doc_id}: 남은 개념 없음")
                continue
            # 문서 간 병합 — 앞 문서가 만든 노드에 붙인다.
            outcome = await resolve_against_graph(
                result.concepts, result.relations,
                graph=host.query_view(), pack=pack, embedding=embedding,
                params=ResolveParams(candidate_limit=args.candidate_limit,
                                     embedding_enabled=args.resolve_embedding,
                                     similarity_threshold=0.93))
            if outcome.stats.candidate_limit_hit:
                limit_hits += 1
                if not args.allow_candidate_limit:
                    raise SystemExit(
                        f"[{n}/{len(docs)}] {doc.doc_id}: 정합 후보 상한에 걸렸습니다 — "
                        f"'일치 없음' 을 믿을 수 없어 중복 노드를 만들게 됩니다. "
                        f"--candidate-limit 을 올리거나 --allow-candidate-limit 로 강행하십시오. "
                        f"(여기까지 {done}문서 저장됨)")
            concepts, relations, blank = drop_blank_canonical(
                outcome.concepts, outcome.relations)
            if blank:
                # 조용히 버리면 개념 수가 줄어든 이유를 알 수 없다.
                total_blank += blank
                print(f"  canonical 이 빈 개념 {blank}건을 버렸습니다 — "
                      f"그래프 `_key` 를 만들 수 없습니다(ERR 1221)")
            if not concepts:
                print(f"[{n}/{len(docs)}] {doc.doc_id}: 쓸 개념이 남지 않음")
                continue
            nodes, edges = host.store(concepts, relations)
            # 노드 하나가 거부돼도 적재는 계속된다(쓸 수 없는 문자 등).
            # 건너뛴 것을 모아 끝에 말한다 - 세지 않으면 그래프가 왜 비어
            # 보이는지 알 수 없다.
            store_failures.extend(getattr(host, "last_failures", []))
            total_nodes += nodes
            total_edges += edges
            done += 1
            merged = sum(1 for a, b in outcome.stats.mapping.items() if a != b)
            extra = ""
            if outcome.stats.ambiguous:
                extra += f"  애매 {len(outcome.stats.ambiguous)}"
            if outcome.stats.type_conflicts:
                extra += f"  타입충돌 {len(outcome.stats.type_conflicts)}"
            if outcome.stats.candidate_limit_hit:
                extra += "  ← 후보 상한 — '일치 없음' 을 믿을 수 없음"
            print(f"[{n}/{len(docs)}] {doc.doc_id}: 노드 {nodes} 간선 {edges} "
                  f"(기존에 붙임 {merged}){extra}")
            _write(_doc_file(args.work, "stored", doc.doc_id),
                   {"nodes": nodes, "edges": edges, "merged": merged,
                    "resolve": json.loads(outcome.stats.model_dump_json())})
        counts = host.raw_counts()
    except BaseException:
        # 부분 저장 상태를 숨기지 않는다 — 어디까지 들어갔는지 찍고 다시 던진다.
        print(f"\n중단 — 여기까지 {done}문서 저장됨 (stored/ 에 기록). "
              f"이어서 돌리면 저장된 문서는 건너뜁니다.")
        raise
    finally:
        runtime.sync_close()
        host.close()

    print(f"\n쓴 것: 노드 {total_nodes}  간선 {total_edges}  (문서 {done}개)")
    if store_failures:
        print()
        print("=" * 60)
        print(f"그래프에 쓰지 못한 것 {len(store_failures)}건")
        for name, reason in store_failures[:10]:
            print(f"  - {name}: {reason}")
        if len(store_failures) > 10:
            print(f"  ... 그리고 {len(store_failures) - 10}건 더")
        print("=" * 60)
    if total_blank:
        print(f"canonical 이 비어 버린 개념 {total_blank}건 — "
              f"추출이나 정합에서 이름을 잃은 것입니다")
    if limit_hits:
        print(f"정합 후보 상한에 걸린 문서 {limit_hits}개 — 그 문서의 '일치 없음' 은 믿을 수 없음")
    # 엔진을 거치지 않고 다시 센다 — 엔진 버그와 저장소 상태를 갈라야 한다.
    print(f"저장소가 가진 것: 노드 {counts['nodes']}  간선 {counts['edges']}")
    print("타입별:", ", ".join(f"{r['t']}={r['c']}" for r in counts["by_type"]))
    print("술어별:", ", ".join(f"{r['t']}={r['c']}" for r in counts["by_predicate"]))


def step_report(args) -> None:
    """문서별 결과를 한 표로 — 어디서 무엇이 빠졌는지."""
    docs = _load_docs(args.work)
    rows = []
    totals = {"chunks": 0, "concepts": 0, "fallback": 0, "unanchored": 0,
              "kept": 0, "relations": 0, "unknown_types": {}}
    for doc in docs:
        row = {"doc_id": doc.doc_id, "kind": doc.kind, "chunks": len(doc.chunks),
               "extracted": None, "kept": None, "status": "-"}
        ex = _doc_file(args.work, "extracted", doc.doc_id)
        if ex.is_file():
            e = _read(ex)
            row["extracted"] = len(e["concepts"])
            row["status"] = e["status"]
            for t, c in (e["stats"].get("unknown_concept_types") or {}).items():
                totals["unknown_types"][t] = totals["unknown_types"].get(t, 0) + c
        se = _doc_file(args.work, "selected", doc.doc_id)
        if se.is_file():
            s = _read(se)["selection"]
            row["kept"] = s["concepts_out"]
            row["fallback"] = s["dropped_fallback"]
            row["unanchored"] = s["dropped_unanchored"]
            row["relations"] = s["relations_out"]
            totals["fallback"] += s["dropped_fallback"]
            totals["unanchored"] += s["dropped_unanchored"]
            totals["kept"] += s["concepts_out"]
            totals["relations"] += s["relations_out"]
        totals["chunks"] += row["chunks"]
        totals["concepts"] += row["extracted"] or 0
        rows.append(row)

    print(f"{'문서':<40} {'종류':<5} {'청크':>4} {'추출':>5} {'폴백':>5} {'비앵커':>6} {'남음':>5} {'관계':>5}  상태")
    for r in rows:
        print(f"{r['doc_id'][:40]:<40} {r['kind']:<5} {r['chunks']:>4} "
              f"{str(r['extracted'] or '-'):>5} {str(r.get('fallback', '-')):>5} "
              f"{str(r.get('unanchored', '-')):>6} {str(r['kept'] if r['kept'] is not None else '-'):>5} "
              f"{str(r.get('relations', '-')):>5}  {r['status']}")
    print(f"\n합계: 청크 {totals['chunks']}, 추출 개념 {totals['concepts']}, "
          f"폴백 제외 {totals['fallback']}, 비앵커 제외 {totals['unanchored']}, "
          f"선별 후 개념 {totals['kept']}, 관계 {totals['relations']} "
          f"(문서 합 — 같은 이름은 저장에서 합쳐진다. 고유 수는 store 의 '저장소가 가진 것')")
    if totals["unknown_types"]:
        print("팩에 없는 타입(개선 후보):",
              json.dumps(totals["unknown_types"], ensure_ascii=False))
    _write(args.work / "report.json", {"docs": rows, "totals": totals})


async def step_all(args) -> None:
    step_parse(args)
    await step_extract(args)
    step_select(args)
    await step_store(args)
    step_report(args)


# ── CLI ─────────────────────────────────────────────────────
def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="graph_loader", description=__doc__,
                                formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("command", choices=["fetch", "parse", "extract", "select",
                                       "store", "report", "all"])
    p.add_argument("--work", type=pathlib.Path,
                   default=pathlib.Path(os.environ.get("LOADER_WORK", "work/loader")))
    p.add_argument("--blog")
    p.add_argument("--rss", help="fetch: RSS/Atom 피드 URL (블로그·컨퍼런스 소식)")
    p.add_argument("--urls", help="fetch: URL 목록 파일 (한 줄 하나, # 주석)")
    p.add_argument("--fetch-posts", type=int, default=20)
    p.add_argument("--fetch-min-chars", type=int, default=200)
    p.add_argument("--messenger")
    p.add_argument("--chunk-chars", type=int, default=1500)
    p.add_argument("--gap-minutes", type=int, default=30)
    p.add_argument("--packs", default=str(ENGINE / "packs"))
    p.add_argument("--pack", default="",
                   help="도메인 팩 id — fetch 외 모든 명령에서 필수 (범용 툴이라 기본값이 없다)")
    p.add_argument("--index", default=os.environ.get("LOADER_INDEX", ""),
                   help="그래프 인덱스 (기본: 팩 id)")
    p.add_argument("--anchor-types", default="",
                   help="앵커 개념 타입 (쉼표 구분, select/all 필수) — 예: System,Symptom / Model,Framework")
    p.add_argument("--strategy", choices=["prompt", "konlp", "hybrid"], default="prompt")
    p.add_argument("--batch", type=int, default=2)
    p.add_argument("--concurrency", type=int, default=2,
                   help="한 문서 안의 프롬프트 묶음 동시 호출 수")
    p.add_argument("--extract-retries", type=int, default=1,
                   help="실패한 문서를 몇 번 더 시도하나 — 사내 LLM 이 일시적으로 "
                        "400 을 뱉고 다음에는 통하는 일이 있다. 0 이면 재시도 없음")
    p.add_argument("--doc-concurrency", type=int, default=1,
                   help="문서 동시 처리 수 — 짧은 문서가 많으면 --concurrency 만으로는 "
                        "빨라지지 않는다(묶음이 1개뿐이다). LLM 호출은 둘의 곱이 된다")
    p.add_argument("--max-tokens", type=int, default=8192)
    p.add_argument("--min-term-freq", type=int, default=1)
    p.add_argument("--reset", action="store_true")
    p.add_argument("--resolve-embedding", action="store_true")
    p.add_argument("--candidate-limit", type=int, default=2000)
    p.add_argument("--graph-provider",
                   choices=["neo4j", "arangodb", "apache_age"],
                   default=os.environ.get("LOADER_GRAPH_PROVIDER", "neo4j"),
                   help="그래프 저장소 — Neo4j 라이선스 불가 시 arangodb 또는 apache_age(OSI)")
    p.add_argument("--arango-url", default=os.environ.get("LOADER_ARANGO_URL", "http://localhost:18529"))
    p.add_argument("--arango-username", default=os.environ.get("LOADER_ARANGO_USERNAME", "root"))
    p.add_argument("--arango-password", default=os.environ.get("LOADER_ARANGO_PASSWORD", "testpassword"))
    p.add_argument("--arango-database", default=os.environ.get("LOADER_ARANGO_DATABASE", "_system"))
    p.add_argument("--age-url", default=os.environ.get("LOADER_AGE_URL", "postgresql://localhost:15455/"),
                   help="Apache AGE(PostgreSQL) 접속 DSN")
    p.add_argument("--age-username", default=os.environ.get("LOADER_AGE_USERNAME", "postgres"))
    p.add_argument("--age-password", default=os.environ.get("LOADER_AGE_PASSWORD", "testpassword"))
    p.add_argument("--age-database", default=os.environ.get("LOADER_AGE_DATABASE", "omniai"))
    p.add_argument("--allow-candidate-limit", action="store_true",
                   help="정합 후보 상한에 걸려도 계속 진행 (기본: 중단)")
    for key, value in lab.DEFAULTS.items():
        p.add_argument(f"--{key.replace('_', '-')}", default=value)
    return p


def main() -> int:
    args = build_parser().parse_args()
    graph_target = {"arangodb": args.arango_url,
                    "apache_age": args.age_url}.get(args.graph_provider, args.neo4j_url)
    print(f"설정: work={args.work} packs={args.packs} pack={args.pack} "
          f"index={args.index} graph={args.graph_provider}:{graph_target} "
          f"llm={args.llm_url}")
    if args.command != "fetch" and not args.pack:
        raise SystemExit("--pack 이 필요합니다 — 범용 툴이라 도메인 기본값이 없습니다")
    if args.command in ("select", "all") and not args.anchor_types:
        raise SystemExit("--anchor-types 가 필요합니다 (예: Model,Framework) — "
                         "앵커 없이는 선별할 수 없습니다")
    if not args.index:
        args.index = args.pack
    steps = {"fetch": step_fetch, "parse": step_parse, "extract": step_extract,
             "select": step_select, "store": step_store, "report": step_report,
             "all": step_all}
    fn = steps[args.command]
    if asyncio.iscoroutinefunction(fn):
        asyncio.run(fn(args))
    else:
        fn(args)
    return 0


if __name__ == "__main__":
    sys.exit(main())
