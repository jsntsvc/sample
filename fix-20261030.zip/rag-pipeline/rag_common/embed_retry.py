# -*- coding: utf-8 -*-
"""임베딩 서버가 늦거나 끊겼을 때 다시 시도한다.

임베딩은 외부 서버에 HTTP 로 보낸다. 서버가 과부하이거나 재기동 중이면 한두 번
늦어지는데, 그것으로 문서 하나가 실패하면 안 된다.

**재시도를 큐 뒤로 보내지 않는다.** 현장 토픽에 4만 건이 밀려 있으면 뒤로 보낸
것은 몇 시간 뒤에 돌아온다. 그 사이 그 문서는 청크 일부만 벡터DB 에 있는 상태로
남고, 검색은 조용히 불완전한 결과를 돌려준다. 문서가 실패한 것보다 나쁘다.
그래서 실패한 배치만 **제자리에서** 다시 시도한다.

일시적인 것만 다시 시도한다. 400(입력이 너무 길다, 모양이 틀렸다)은 세 번
보내 봐야 임베딩 서버만 괴롭힌다.

재시도를 다 소진하면 부르는 쪽이 그 문서·리비전의 벡터를 지워 "아무것도
색인되지 않았다" 는 깨끗한 상태로 만든 뒤 실패를 통지한다.
"""
from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Callable, Sequence, Tuple, TypeVar

import requests
from loguru import logger

T = TypeVar("T")

_DEFAULT_ATTEMPTS = 3
_DEFAULT_BACKOFF: Tuple[float, ...] = (2.0, 8.0, 30.0)

# 다시 해 볼 만한 응답 코드. 429 는 동시 요청이 많아 거절된 것이라 기다리면 된다.
_TRANSIENT_STATUS = {408, 429, 500, 502, 503, 504, 507, 509}


def is_transient(error: BaseException) -> bool:
    """다시 시도할 만한 오류인가.

    모르는 오류는 일시적으로 본다 — 다시 해 보는 쪽이 낫고, 영구적이면 횟수를
    소진하고 끝난다. 반대로 두면 알 수 없는 오류 하나에 문서가 바로 실패한다.
    """
    if isinstance(error, requests.exceptions.HTTPError):
        response = getattr(error, "response", None)
        status = getattr(response, "status_code", None)
        if status is None:
            # 응답을 알 수 없으면 판단하지 않고 다시 해 본다.
            return True
        return status in _TRANSIENT_STATUS
    # Timeout, ConnectionError 는 RequestException 의 하위다.
    return True


class EmptyEmbeddingResult(RuntimeError):
    """200 인데 벡터가 없다. 그냥 넘기면 그 청크가 조용히 빠진다."""


@dataclass
class RetryPolicy:
    """몇 번, 얼마를 기다리며 다시 할지.

    :param max_attempts: 총 시도 횟수. 1 이면 재시도하지 않는다(기존 동작)
    :param backoff_sec: 시도 사이 간격. 모자라면 마지막 값을 계속 쓴다
    :param sleep: 기다리는 함수. 테스트에서 갈아 끼운다
    """

    max_attempts: int = _DEFAULT_ATTEMPTS
    backoff_sec: Tuple[float, ...] = _DEFAULT_BACKOFF
    sleep: Callable[[float], None] = field(default=time.sleep, repr=False)

    @classmethod
    def from_env(cls) -> "RetryPolicy":
        """운영이 정하는 값이라 설정 파일이나 환경변수로 받는다.

        오타가 나도 적재가 멈추면 안 되므로, 읽을 수 없으면 기본값을 쓴다.
        """
        from rag_common.config import get_setting

        raw_attempts = get_setting("EMBED_RETRY_MAX_ATTEMPTS")
        try:
            attempts = int(str(raw_attempts).strip()) if raw_attempts else _DEFAULT_ATTEMPTS
        except ValueError:
            logger.warning(f"EMBED_RETRY_MAX_ATTEMPTS 를 읽을 수 없어 기본값을 씁니다: {raw_attempts}")
            attempts = _DEFAULT_ATTEMPTS
        attempts = max(1, attempts)

        raw_backoff = get_setting("EMBED_RETRY_BACKOFF_SEC")
        # 설정 파일에는 `[2, 8, 30]` 으로 적는 쪽이 자연스럽다. 둘 다 받는다.
        if isinstance(raw_backoff, (list, tuple)):
            raw_backoff = ",".join(str(x) for x in raw_backoff)
        backoff: Tuple[float, ...] = _DEFAULT_BACKOFF
        if raw_backoff:
            try:
                parsed = tuple(float(p.strip()) for p in str(raw_backoff).split(",") if p.strip())
                if parsed:
                    backoff = parsed
            except ValueError:
                logger.warning(f"EMBED_RETRY_BACKOFF_SEC 를 읽을 수 없어 기본값을 씁니다: {raw_backoff}")

        return cls(max_attempts=attempts, backoff_sec=backoff)

    def wait_before(self, attempt: int) -> float:
        """``attempt`` 번째 시도 전에 기다릴 시간. attempt 는 2부터."""
        if not self.backoff_sec:
            return 0.0
        index = min(attempt - 2, len(self.backoff_sec) - 1)
        return self.backoff_sec[max(0, index)]


def retry_embedding(call: Callable[[], T], policy: RetryPolicy,
                    what: str = "임베딩") -> T:
    """``call`` 을 돌리고, 일시적 실패면 간격을 두고 다시 한다.

    빈 결과도 실패로 본다 — 서버가 200 에 빈 목록을 돌려주는 일이 있었고,
    그냥 넘기면 그 청크들이 조용히 빠진다.

    횟수를 소진하면 **마지막 시도의 오류를 그대로 올린다.** 부르는 쪽이 그것을
    보고 실패 단계와 사유를 통지한다.
    """
    last: BaseException | None = None
    for attempt in range(1, policy.max_attempts + 1):
        if attempt > 1:
            delay = policy.wait_before(attempt)
            if delay:
                logger.warning(
                    f"{what} 재시도 대기 {delay:g}초 "
                    f"({attempt}/{policy.max_attempts}번째 시도): {last}")
                policy.sleep(delay)
        try:
            result = call()
        except Exception as e:  # noqa: BLE001 — 아래에서 가린다
            last = e
            if not is_transient(e):
                logger.error(f"{what} 실패 — 다시 해도 같은 결과입니다(재시도 안 함): {e}")
                raise
            if attempt >= policy.max_attempts:
                logger.error(f"{what} 재시도를 {policy.max_attempts}번 모두 소진했습니다: {e}")
                raise
            continue

        if not result:
            last = EmptyEmbeddingResult(
                f"{what} 결과가 비어 있습니다(서버가 200 에 빈 목록을 돌려줌)")
            if attempt >= policy.max_attempts:
                logger.error(f"{what} 재시도를 {policy.max_attempts}번 모두 소진했습니다: {last}")
                raise last
            continue

        if attempt > 1:
            logger.info(f"{what} 재시도 성공 ({attempt}/{policy.max_attempts}번째 시도)")
        return result

    # 위 루프가 반드시 반환하거나 올린다. 방어적으로 둔다.
    raise last if last else RuntimeError(f"{what} 실패")
