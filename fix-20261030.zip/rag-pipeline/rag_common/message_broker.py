"""
메시지 브로커 추상화 모듈.

Redis Stream / Kafka 등 서로 다른 메시지 브로커 구현을 단일 인터페이스로 추상화.
4개 워커(etl/chunk/embed/graphdb)는 MessageBroker 타입만 의존하므로
Kafka 전환 시 워커 코드 변경 없이 구현체만 교체 가능.
"""

import json
import os
import time
from abc import ABC, abstractmethod
from typing import Any, Dict, Optional, Tuple

import redis
from loguru import logger

from .config import Config


# 기본 1시간. 한 건 처리에 허용할 시간이며, 넘기면 브로커가 컨슈머를 그룹에서 뺀다.
_DEFAULT_MAX_POLL_INTERVAL_MS = 3600000


def _max_poll_interval_ms() -> int:
    """컨슈머가 poll() 사이에 머물 수 있는 최대 시간(ms).

    Config 에 값이 있으면 그걸 쓰고, 없으면 환경변수와 기본값으로 떨어진다.
    현장에서 이 파일 하나만 바꿔 끼우는 경우(구버전 config.py 와 섞임)에도
    동작해야 하기 때문이다.
    """
    value = getattr(Config, "KAFKA_MAX_POLL_INTERVAL_MS", None)
    if value is None:
        value = os.getenv("KAFKA_MAX_POLL_INTERVAL_MS") or _DEFAULT_MAX_POLL_INTERVAL_MS
    try:
        return int(value)
    except (TypeError, ValueError):
        logger.warning(
            f"KAFKA_MAX_POLL_INTERVAL_MS 값을 읽을 수 없어 기본값을 씁니다: {value!r}"
        )
        return _DEFAULT_MAX_POLL_INTERVAL_MS


# ──────────────────────────────────────────────────────────
# Exceptions
# ──────────────────────────────────────────────────────────

class BrokerPublishError(Exception):
    """publish / send_result 실패 시 발생."""

    def __init__(self, stream: str, reason: str, cause: Optional[Exception] = None):
        self.stream = stream
        self.reason = reason
        self.cause = cause
        super().__init__(f"[PUBLISH_FAIL] stream={stream} reason={reason}")


class BrokerConsumeError(Exception):
    """read_message / ack / ensure_consumer_group 실패 시 발생."""

    def __init__(self, stream: str, group: str, reason: str, cause: Optional[Exception] = None):
        self.stream = stream
        self.group = group
        self.reason = reason
        self.cause = cause
        super().__init__(f"[CONSUME_FAIL] stream={stream} group={group} reason={reason}")


# ──────────────────────────────────────────────────────────
# Abstract Interface
# ──────────────────────────────────────────────────────────

class MessageBroker(ABC):
    """
    메시지 브로커 추상화 인터페이스.

    구현체:
      - RedisStreamBroker (기본)
      - KafkaBroker (별도 구현)
    """

    # ack 가 누적인가.
    #
    # Kafka 는 오프셋 하나를 커밋하면 그 앞의 것이 모두 끝난 것이 된다. 그래서
    # 여러 건을 동시에 처리할 때 **빈틈없이 이어진 앞부분까지만** 커밋해야 한다.
    # Redis 는 XACK 가 건별이라 끝난 것을 하나씩 ack 해야 하고, 하나만 ack 하면
    # 나머지가 PEL 에 영구히 남는다.
    #
    # 기본값은 False 다 — 모르는 브로커를 누적으로 보면 조용히 유실된다.
    cumulative_ack: bool = False

    # ----- Consumer Group 관리 -----

    @abstractmethod
    def ensure_consumer_group(self, stream: str, group: str) -> None:
        """Consumer group 존재 보장 (idempotent)."""

    # ----- Producer -----

    @abstractmethod
    def publish(self, stream: str, task: Dict[str, Any]) -> str:
        """
        task stream에 메시지 발행.

        Returns: 구현체별 message_id (Redis record_id 또는 Kafka offset)
        Raises: BrokerPublishError
        """

    @abstractmethod
    def send_result(self, result_stream: str, result: Dict[str, Any]) -> str:
        """
        결과 stream에 메시지 발행. publish와 유사하지만
        result용 maxlen/retention 정책을 분리 적용할 수 있게 별도 메서드로 둠.
        """

    # ----- Consumer -----

    @abstractmethod
    def read_message(
        self,
        stream: str,
        group: str,
        consumer: str,
        timeout_ms: int = 5000,
        claim_pending: bool = True,
    ) -> Optional[Tuple[str, Dict[str, Any]]]:
        """
        stream에서 단일 메시지 수신 (blocking, timeout).

        Args:
            stream: 구독 stream/topic 이름
            group: consumer group
            consumer: consumer name (Kafka에서는 client.id)
            timeout_ms: 대기 시간 (밀리초)
            claim_pending: Redis PEL stale 메시지 reclaim 여부 (Kafka에서는 무시)

        Returns: (message_id, message_data) 또는 None (timeout)
        Raises: BrokerConsumeError
        """

    @abstractmethod
    def ack(self, stream: str, group: str, message_id: str) -> None:
        """메시지 처리 완료 알림."""

    # ----- Observability (선택적) -----

    def get_stream_info(self, stream: str, group: str) -> Dict[str, Any]:
        """
        디버깅/모니터링용 stream 상태 요약.
        default 구현은 빈 dict. 구현체가 선택적으로 오버라이드.

        Returns:
            {"length": int, "pending_count": int, "pending_samples": [...]}
        """
        return {}

    # ----- Lifecycle -----

    def close(self) -> None:
        """리소스 정리 (default no-op)."""
        pass


# ──────────────────────────────────────────────────────────
# Redis Stream 구현체
# ──────────────────────────────────────────────────────────

class RedisStreamBroker(MessageBroker):
    """
    Redis Stream 기반 MessageBroker 구현.

    기존 rag_common.redis_stream.RedisStreamClient 로직을 재구성하여
    stream/group/consumer를 메서드 파라미터로 받도록 변경.
    """

    def __init__(self):
        from .redis_client import get_redis_client
        self._redis = get_redis_client()
        if Config.is_redis_cluster():
            logger.info(
                f"[BROKER_INIT] backend=redis(cluster) nodes={Config.REDIS_CLUSTER_NODES}"
            )
        else:
            logger.info(
                f"[BROKER_INIT] backend=redis host={Config.REDIS_HOST}:{Config.REDIS_PORT} db={Config.REDIS_DB}"
            )

    # ----- Consumer Group 관리 -----

    def ensure_consumer_group(self, stream: str, group: str) -> None:
        try:
            self._redis.xgroup_create(name=stream, groupname=group, id="0", mkstream=True)
            logger.info(f"Consumer Group 생성: stream={stream}, group={group}")
        except redis.exceptions.ResponseError as e:
            if "BUSYGROUP" in str(e):
                logger.debug(f"Consumer Group 이미 존재: stream={stream}, group={group}")
                return
            raise BrokerConsumeError(stream, group, f"ensure_group: {e}", e)
        except Exception as e:
            raise BrokerConsumeError(stream, group, f"ensure_group: {e}", e)

    # ----- Producer -----

    def publish(self, stream: str, task: Dict[str, Any]) -> str:
        try:
            stream_data = self._serialize(task)
            maxlen = Config.REDIS_STREAM_MAXLEN
            record_id = self._redis.xadd(stream, stream_data, maxlen=maxlen, approximate=True)
            logger.info(f"publish 완료: stream={stream}, record_id={record_id}")
            return record_id
        except Exception as e:
            logger.error(f"[PUBLISH_FAIL] stream={stream} reason={e}")
            raise BrokerPublishError(stream, str(e), e)

    def send_result(self, result_stream: str, result: Dict[str, Any]) -> str:
        # Redis에서는 publish와 동일 동작. Kafka 구현 시 별도 topic/정책 적용 가능.
        try:
            stream_data = self._serialize(result)
            maxlen = Config.REDIS_STREAM_MAXLEN
            record_id = self._redis.xadd(
                result_stream, stream_data, maxlen=maxlen, approximate=True
            )
            logger.info(f"결과 전송 완료: record_id={record_id}")
            return record_id
        except Exception as e:
            logger.error(f"[PUBLISH_FAIL] stream={result_stream} reason={e}")
            raise BrokerPublishError(result_stream, str(e), e)

    # ----- Consumer -----

    def read_message(
        self,
        stream: str,
        group: str,
        consumer: str,
        timeout_ms: int = 5000,
        claim_pending: bool = True,
    ) -> Optional[Tuple[str, Dict[str, Any]]]:
        try:
            # 1. PEL 기반 stale 메시지 우선 처리
            if claim_pending:
                claimed = self._claim_pending(stream, group, consumer)
                if claimed:
                    return claimed

            # 2. 새 메시지 수신
            messages = self._redis.xreadgroup(
                groupname=group,
                consumername=consumer,
                streams={stream: ">"},
                count=1,
                block=timeout_ms,
            )
            if messages:
                for _stream_name, stream_messages in messages:
                    for message_id, message_data in stream_messages:
                        logger.debug(f"메시지 수신: stream={stream}, id={message_id}")
                        return (message_id, message_data)
            return None
        except redis.exceptions.ConnectionError as e:
            logger.error(f"[CONSUME_FAIL] stream={stream} group={group} reason=connection: {e}")
            raise BrokerConsumeError(stream, group, f"connection: {e}", e)
        except Exception as e:
            logger.error(f"[CONSUME_FAIL] stream={stream} group={group} reason={e}", exc_info=True)
            raise BrokerConsumeError(stream, group, str(e), e)

    def _claim_pending(
        self,
        stream: str,
        group: str,
        consumer: str,
        min_idle_ms: int = 10000,
    ) -> Optional[Tuple[str, Dict[str, Any]]]:
        """Pending Entries List에서 stale 메시지 reclaim. 실패는 조용히 무시."""
        try:
            pending_info = self._redis.xpending_range(
                name=stream, groupname=group, min="-", max="+", count=10
            )
            if not pending_info:
                return None

            claimable = [
                m for m in pending_info if m.get("time_since_delivered", 0) >= min_idle_ms
            ]
            if not claimable:
                return None

            msg = claimable[0]
            message_id = msg["message_id"]
            claimed = self._redis.xclaim(
                name=stream,
                groupname=group,
                consumername=consumer,
                min_idle_time=min_idle_ms,
                message_ids=[message_id],
            )
            if claimed:
                for claimed_id, claimed_data in claimed:
                    logger.info(
                        f"PEL claim 성공: id={claimed_id}, "
                        f"idle_time={msg.get('time_since_delivered', 0)}ms"
                    )
                    return (claimed_id, claimed_data)
            return None
        except Exception as e:
            logger.debug(f"PEL claim 실패(무시): {e}")
            return None

    def ack(self, stream: str, group: str, message_id: str) -> None:
        try:
            self._redis.xack(stream, group, message_id)
            # 기존 RedisStreamClient 동작과 동일하게 ACK 후 stream에서 삭제 (메모리 정리)
            self._redis.xdel(stream, message_id)
        except Exception as e:
            logger.error(f"[CONSUME_FAIL] stream={stream} group={group} reason=ack: {e}")
            raise BrokerConsumeError(stream, group, f"ack: {e}", e)

    # ----- Observability -----

    def get_stream_info(self, stream: str, group: str) -> Dict[str, Any]:
        """xlen + xpending 요약 + 샘플 5개."""
        try:
            length = self._redis.xlen(stream)
            pending_summary = self._redis.xpending(name=stream, groupname=group) or {}
            pending_count = pending_summary.get("pending", 0) if isinstance(pending_summary, dict) else 0
            samples = []
            try:
                rows = self._redis.xpending_range(
                    name=stream, groupname=group, min="-", max="+", count=5
                )
                for m in rows:
                    samples.append({
                        "message_id": m.get("message_id"),
                        "consumer": m.get("consumer"),
                        "idle_ms": m.get("time_since_delivered", 0),
                        "delivery_count": m.get("times_delivered", 0),
                    })
            except Exception:
                pass
            return {"length": length, "pending_count": pending_count, "pending_samples": samples}
        except Exception as e:
            logger.debug(f"get_stream_info 실패: {e}")
            return {}

    # ----- Lifecycle -----

    def close(self) -> None:
        try:
            self._redis.close()
        except Exception:
            pass

    # ----- Serialization (기존 safe_str 로직 이식) -----

    @staticmethod
    def _serialize(data: Dict[str, Any]) -> Dict[str, str]:
        """Redis Stream은 flat dict of strings만 받음. None/빈값 필터 + 중첩은 JSON stringify."""

        def safe_str(value, default=""):
            if value is None:
                return default
            if isinstance(value, (dict, list)):
                return json.dumps(value, ensure_ascii=False, default=str)
            return str(value)

        return {k: safe_str(v) for k, v in data.items() if v is not None and v != ""}


# ──────────────────────────────────────────────────────────
# Kafka 구현체 (스켈레톤)
# ──────────────────────────────────────────────────────────

class KafkaBroker(MessageBroker):
    """
    Kafka 기반 MessageBroker 실구현.

    매핑:
        stream ↔ topic
        consumer_group ↔ group.id
        consumer_name ↔ client.id
        xadd ↔ producer.produce()
        xreadgroup ↔ consumer.poll()
        xack + xdel ↔ consumer.commit() (offset)
        PEL claim ↔ rebalance가 자동 처리 → claim_pending은 no-op

    페이로드: Redis Stream(flat map of strings)과 달리 Kafka는 JSON string value를 사용.
    워커 수신부는 이미 `task` 필드가 JSON string인 케이스를 처리하므로 호환.
    """

    # Kafka 커밋은 누적이다. 오프셋 하나를 커밋하면 그 앞의 것이 모두 끝난
    # 것이 되므로, 여러 건을 동시에 처리할 때는 빈틈없이 이어진 앞부분까지만
    # 올려야 한다. Redis 는 XACK 가 건별이라 다르다(MessageBroker 주석 참고).
    cumulative_ack = True

    def __init__(self):
        try:
            from confluent_kafka import Producer, Consumer
        except ImportError as e:
            raise ImportError(
                "confluent-kafka 패키지가 필요합니다. `pip install confluent-kafka` 실행."
            ) from e
        self._Producer = Producer
        self._Consumer = Consumer
        self._bootstrap = Config.KAFKA_BOOTSTRAP_SERVERS
        # 공통 보안 옵션(SASL/SSL) — bootstrap.servers 포함
        self._security_cfg = Config.kafka_client_config()
        producer_cfg: Dict[str, Any] = {
            **self._security_cfg,
            "client.id": "rag-worker-producer",
            # 큰 ETL payload(full content) 수용. Kafka topic max.message.bytes와 맞춤
            "message.max.bytes": 10485760,  # 10MB
        }
        self._producer = Producer(producer_cfg)
        # (topic, group) → Consumer 인스턴스 (read_message 호출 시 lazy 생성)
        self._consumers: Dict[Tuple[str, str], Any] = {}
        logger.info(
            f"[BROKER_INIT] backend=kafka bootstrap={self._bootstrap} "
            f"security={self._security_cfg.get('security.protocol', 'PLAINTEXT')} "
            f"sasl={self._security_cfg.get('sasl.mechanism', '-')}"
        )

    # ----- Consumer Group 관리 -----

    def ensure_consumer_group(self, stream: str, group: str) -> None:
        """Kafka는 consumer.poll() 시점에 group이 자동 등록/rebalance되므로 no-op."""
        logger.debug(f"ensure_consumer_group (kafka no-op): topic={stream}, group={group}")

    # ----- Producer -----

    def publish(self, stream: str, task: Dict[str, Any]) -> str:
        stream = self._normalize_topic(stream)
        try:
            value = self._serialize_json(task).encode("utf-8")
            value_size = len(value)
            # per-call state: callback fires before flush() returns — capture error here
            state = {"err": None}

            def _cb(err, msg):
                if err is not None:
                    state["err"] = err
                    logger.error(
                        f"[KAFKA_DELIVERY_FAIL] topic={msg.topic() if msg else stream} "
                        f"size={value_size} err={err}"
                    )

            self._producer.produce(stream, value=value, callback=_cb)
            # flush(5s)만으로는 충분하지 않음: flush는 "큐에서 제거"됐는지만 봄.
            # 브로커 reject (size/ACL/quota)는 callback으로만 전달되므로 state["err"] 확인 필수.
            remaining = self._producer.flush(5.0)
            if remaining > 0:
                raise BrokerPublishError(
                    stream, f"flush timeout: {remaining} message(s) undelivered, size={value_size}"
                )
            if state["err"] is not None:
                raise BrokerPublishError(
                    stream, f"delivery failed size={value_size}: {state['err']}"
                )
            record_id = f"kafka-{stream}-{int(time.time() * 1000)}"
            logger.info(
                f"publish 완료 (kafka): topic={stream}, size={value_size}, record_id={record_id}"
            )
            return record_id
        except BrokerPublishError:
            raise
        except Exception as e:
            logger.error(f"[PUBLISH_FAIL] topic={stream} reason={e}")
            raise BrokerPublishError(stream, str(e), e)

    def send_result(self, result_stream: str, result: Dict[str, Any]) -> str:
        return self.publish(result_stream, result)

    # ----- Consumer -----

    def read_message(
        self,
        stream: str,
        group: str,
        consumer: str,
        timeout_ms: int = 5000,
        claim_pending: bool = True,
    ) -> Optional[Tuple[str, Dict[str, Any]]]:
        stream = self._normalize_topic(stream)
        key = (stream, group)
        c = self._consumers.get(key)
        if c is None:
            c = self._Consumer({
                **self._security_cfg,
                "group.id": group,
                "client.id": consumer,
                "enable.auto.commit": False,
                "auto.offset.reset": "earliest",
                # ETL full content 같은 큰 메시지 수용
                "fetch.message.max.bytes": 10485760,  # 10MB
                "max.partition.fetch.bytes": 10485760,
                # 메시지 하나를 문서 한 건 처리에 다 쓰므로 poll 간격이 길다.
                # 기본 5분을 넘기면 그룹에서 쫓겨나고 commit 이 UNKNOWN_MEMBER_ID 로 깨진다.
                "max.poll.interval.ms": _max_poll_interval_ms(),
            })
            c.subscribe([stream])
            self._consumers[key] = c
            logger.info(f"Kafka Consumer 생성: topic={stream}, group={group}, client.id={consumer}")

        try:
            msg = c.poll(timeout_ms / 1000.0)
        except Exception as e:
            raise BrokerConsumeError(stream, group, f"poll: {e}", e)
        if msg is None:
            return None
        if msg.error():
            raise BrokerConsumeError(stream, group, f"consumer error: {msg.error()}")

        try:
            raw = msg.value().decode("utf-8") if msg.value() else ""
            parsed = json.loads(raw) if raw else {}
            if not isinstance(parsed, dict):
                parsed = {"task": raw}
        except Exception as e:
            raise BrokerConsumeError(stream, group, f"deserialize: {e}", e)

        message_id = f"{msg.partition()}-{msg.offset()}"
        logger.debug(f"메시지 수신 (kafka): topic={stream}, id={message_id}")
        return (message_id, parsed)

    def ack(self, stream: str, group: str, message_id: str) -> None:
        """commit 수행.

        ``message_id`` 가 ``"partition-offset"`` 이면 **그 오프셋만** 커밋한다.
        읽히지 않으면 예전처럼 읽은 위치 전체를 커밋한다.

        한 건씩 처리할 때는 둘이 같지만, 스레드로 여러 건을 동시에 들고 있으면 다르다.
        10·11·12 를 가져가 10 이 먼저 끝났을 때 읽은 위치(13)를 커밋하면 아직 처리
        중인 11·12 가 끝난 것이 되고, 파드가 죽으면 그 두 건은 다시 오지 않는다.
        어디까지 올려도 되는지는 OffsetTracker 가 정한다.
        """
        stream = self._normalize_topic(stream)
        key = (stream, group)
        c = self._consumers.get(key)
        if c is None:
            logger.warning(f"ack 호출 시 consumer 없음: topic={stream}, group={group}")
            return
        try:
            from rag_common.concurrency import OffsetTracker
            parsed = OffsetTracker.parse_id(message_id)
            if parsed is not None:
                from confluent_kafka import TopicPartition
                partition, offset = parsed
                # 커밋 오프셋은 "다음에 읽을 위치" 다.
                c.commit(offsets=[TopicPartition(stream, partition, offset + 1)],
                         asynchronous=False)
            else:
                c.commit(asynchronous=False)
        except Exception as e:
            # UNKNOWN_MEMBER_ID / ILLEGAL_GENERATION 은 "처리가 너무 오래 걸려 그룹에서
            # 빠졌다" 는 뜻이다. 결과는 이미 결과 토픽으로 나갔지만 오프셋이 안 올라가
            # 같은 메시지가 다시 온다. 그냥 "commit 실패" 로만 남기면 원인을 알 수 없어,
            # 무엇을 조정해야 하는지까지 적는다.
            text = str(e)
            if "UNKNOWN_MEMBER_ID" in text or "ILLEGAL_GENERATION" in text:
                logger.error(
                    f"[COMMIT_EVICTED] topic={stream} group={group} id={message_id} - "
                    f"처리 중 컨슈머 그룹에서 빠져 오프셋을 올리지 못했습니다. "
                    f"한 건 처리 시간이 max.poll.interval.ms"
                    f"({_max_poll_interval_ms()}ms)를 넘었을 때 납니다. "
                    f"같은 메시지가 다시 전달되므로 중복 처리가 반복됩니다. "
                    f"KAFKA_MAX_POLL_INTERVAL_MS 를 올리십시오. 원인: {e}"
                )
            raise BrokerConsumeError(stream, group, f"commit: {e}", e)

    # ----- Observability (Kafka는 별도 관리) -----

    def get_stream_info(self, stream: str, group: str) -> Dict[str, Any]:
        """컨슈머 그룹의 lag 을 센다.

        Redis 의 XLEN 에 해당하는 값이 Kafka 에는 없다. 파티션마다 끝 오프셋에서
        그룹이 커밋한 오프셋을 빼서 더한 것이 아직 읽지 않은 건수다.

        청킹을 멈출지 정하는 데 쓴다(역압). 호출이 공짜가 아니므로 부르는 쪽에서
        간격을 둔다. 실패하면 -1 을 돌려주고, 받는 쪽은 그때 멈추지 않는다 —
        브로커 상태를 못 봤다고 적재를 세울 이유는 없다.
        """
        # publish/read/ack 와 같은 이름으로 물어야 한다. 설정의 스트림 이름은
        # Redis 식(`rag:embed:stream`)이고 Kafka 토픽은 '.' 다. 이것을 빼먹어
        # 있는 토픽을 없다고 보고 -1 을 돌려주었고, 받는 쪽(역압)은 -1 을
        # "브로커 상태를 못 봤다" 로 보고 통과시켰다. 그래서 역압이 Kafka 에서
        # 한 번도 동작하지 않았다.
        stream = self._normalize_topic(stream)
        try:
            from confluent_kafka import TopicPartition
            from confluent_kafka.admin import AdminClient

            admin = getattr(self, "_admin", None)
            if admin is None:
                # Producer·Consumer 와 같은 보안 설정으로 붙어야 한다.
                # bootstrap 만 주면 SASL 을 요구하는 브로커가 핸드쉐이크 전에
                # 연결을 끊고(Disconnected / connection closed by peer), 이 경로를
                # 타는 청킹 워커만 접속 오류를 끝없이 낸다. _security_cfg 에
                # bootstrap.servers 가 이미 들어 있다.
                admin = AdminClient({**self._security_cfg})
                self._admin = admin

            meta = admin.list_topics(topic=stream, timeout=10)
            tmeta = meta.topics.get(stream)
            if tmeta is None or tmeta.error is not None:
                return {"length": -1, "pending_count": -1, "pending_samples": []}
            parts = [TopicPartition(stream, p) for p in tmeta.partitions]
            if not parts:
                return {"length": 0, "pending_count": 0, "pending_samples": []}

            # 조회 전용 컨슈머. subscribe 하지 않으므로 그룹에 들어가지 않는다 —
            # 깊이를 보려다 리밸런스를 일으키면 안 된다.
            probe = self._probes.get(group) if hasattr(self, "_probes") else None
            if probe is None:
                probe = self._Consumer({
                    **self._security_cfg,
                    "group.id": group,
                    "client.id": f"lag-probe-{group}",
                    "enable.auto.commit": False,
                })
                if not hasattr(self, "_probes"):
                    self._probes = {}
                self._probes[group] = probe
            consumer = probe
            committed = consumer.committed(parts, timeout=10)
            committed_by_part = {tp.partition: tp.offset for tp in (committed or [])}

            lag = 0
            for tp in parts:
                low, high = consumer.get_watermark_offsets(tp, timeout=10, cached=False)
                off = committed_by_part.get(tp.partition)
                if off is None or off < 0:
                    # 아직 커밋한 적이 없는 그룹. 컨슈머가 earliest 부터 읽으므로
                    # 남아 있는 것 전부가 밀린 양이다. 여기서 0 으로 보면 처음
                    # 뜰 때 쌓여 있는 것을 못 보고 역압이 걸리지 않는다.
                    off = low
                lag += max(0, high - off)
            return {"length": lag, "pending_count": lag, "pending_samples": []}
        except Exception as e:
            logger.debug(f"Kafka lag 조회 실패(무시): topic={stream} group={group} error={e}")
            return {"length": -1, "pending_count": -1, "pending_samples": []}

    # ----- Lifecycle -----

    def close(self) -> None:
        try:
            self._producer.flush(5.0)
        except Exception:
            pass
        for c in self._consumers.values():
            try:
                c.close()
            except Exception:
                pass

    # ----- Serialization -----

    @staticmethod
    def _serialize_json(data: Dict[str, Any]) -> str:
        """Redis flat map 대신 JSON string 1개 value로 직렬화."""
        clean = {}
        for k, v in data.items():
            if v is None or v == "":
                continue
            clean[k] = v
        return json.dumps(clean, ensure_ascii=False, default=str)

    @staticmethod
    def _normalize_topic(name: str) -> str:
        """Kafka는 topic 이름에 ':' 불가 → '.'로 치환.
        Redis stream 이름(`rag:etl:stream`)이 Kafka topic(`rag.etl.stream`)으로 자동 매핑."""
        return name.replace(":", ".") if name else name
