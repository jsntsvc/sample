"""
공통 설정 관리 모듈 — Layered Config Loader

우선순위 (높음 → 낮음):
  1. config/config-{env}.yml       (프로파일별 외부 오버라이드)
  2. config/config.yml             (공통 외부 오버라이드)
  3. 환경변수 (os.environ, .env 포함)
  4. 코드 내장 기본값

환경 선택: APP_ENV 또는 OMNIAI_ENV 환경변수 (default: "dev")
config 경로 오버라이드: OMNIAI_CONFIG_DIR 환경변수 (default: "./config")

이미지 빌드 시 devops 측 Dockerfile 에서 /app/config/ 디렉터리에
config.yml + config-{env}.yml 을 패키징하여 배포한다.
K8s 환경변수 주입이 불가하므로 모든 사이트별 값은 config 파일을 통해 주입.
"""

from __future__ import annotations

import os
from pathlib import Path
from typing import Any, Optional

import yaml
from dotenv import load_dotenv

load_dotenv()


# ─── 파일 기반 config 로더 ────────────────────────────────────────────────

def _deep_merge(base: dict, override: dict) -> dict:
    """nested dict 머지. override 가 base 를 키 단위로 덮어쓴다."""
    result = dict(base)
    for k, v in override.items():
        if k in result and isinstance(result[k], dict) and isinstance(v, dict):
            result[k] = _deep_merge(result[k], v)
        else:
            result[k] = v
    return result


def _load_yaml(path: Path) -> dict:
    if not path.exists():
        return {}
    try:
        with path.open("r", encoding="utf-8") as f:
            data = yaml.safe_load(f) or {}
            if not isinstance(data, dict):
                return {}
            return data
    except Exception as e:
        print(f"[config] WARN: failed to load {path}: {e}")
        return {}


def _load_layered_config() -> dict:
    env = os.getenv("APP_ENV") or os.getenv("OMNIAI_ENV") or "dev"
    config_dir = Path(os.getenv("OMNIAI_CONFIG_DIR", "./config"))
    base_path = config_dir / "config.yml"
    override_path = config_dir / f"config-{env}.yml"
    base = _load_yaml(base_path)
    override = _load_yaml(override_path)
    merged = _deep_merge(base, override)
    # 어느 파일을 읽었는지 남긴다. APP_ENV 를 주지 않으면 dev 라, 운영 파일에
    # 적고 반영이 안 된다고 하는 일이 생긴다. 파일을 못 찾은 것도 보여야 한다.
    # 로거 설정 전에 불리므로 print 를 쓴다(위 WARN 과 같은 방식).
    print("[config] env=%s dir=%s config.yml=%s config-%s.yml=%s keys=%d"
          % (env, config_dir, "있음" if base_path.exists() else "없음",
             env, "있음" if override_path.exists() else "없음", len(merged)))
    return merged


_FILE_CONFIG: dict = _load_layered_config()


def _get_env_first(key: str, default: Any = None) -> Any:
    """환경변수 > 파일 > 기본값 순서로 조회. (_get 과 순서가 반대)

    배포 환경이 정해야 하는 값에만 쓴다. 이미지에 들어 있는 설정 파일이 환경변수를
    이기면, 운영자가 값을 줘도 아무 일도 일어나지 않는다.
    """
    env_val = os.getenv(key)
    if env_val is not None and env_val != "":
        return env_val
    raw = _flat_lookup(_FILE_CONFIG, key)
    return default if raw is None else raw


def _flat_lookup(d: dict, key: str) -> Optional[Any]:
    """대문자 SNAKE_CASE 키를 nested dict 에서 조회.
    UPPER_SNAKE_CASE 그대로 매칭 → flat 구조 우선 지원.
    """
    if not d:
        return None
    if key in d:
        return d[key]
    # case-insensitive 보조 매칭
    for k, v in d.items():
        if k.upper() == key.upper():
            return v
    return None


def _get(key: str, default: Any = None, cast=None) -> Any:
    """file > env > default 우선순위로 값 조회.

    cast: 'int' | 'float' | 'bool' | None (str)

    빈 문자열은 *명시적 빈값 의도* 로 간주하여 그대로 반환한다.
    (예: KAFKA_SSL_ENDPOINT_IDENTIFICATION_ALGORITHM: "" 로 hostname 검증 끄기).
    환경변수가 빈 문자열인 경우만 미설정으로 간주하여 default 로 fallback —
    OS 가 빈 문자열 env 를 unset 과 동등하게 다루는 관행과 일치.
    """
    raw: Any = _flat_lookup(_FILE_CONFIG, key)
    if raw is None:
        # 환경변수는 빈 문자열도 unset 으로 간주 (POSIX 관행)
        env_val = os.getenv(key)
        if env_val is not None and env_val != "":
            raw = env_val
    # 파일에서 명시적으로 "" 로 지정한 경우 None 이 아니므로 그대로 사용.
    if raw is None:
        raw = default

    if raw is None:
        return None

    if cast == "int":
        return int(raw)
    if cast == "float":
        return float(raw)
    if cast == "bool":
        if isinstance(raw, bool):
            return raw
        return str(raw).strip().lower() in ("1", "true", "yes", "on")
    return raw if isinstance(raw, str) or cast is None else str(raw)


def get_setting(key: str, default: Any = None, cast=None) -> Any:
    """설정 한 건을 지금 읽는다. 우선순위는 file > env > default 로 같다.

    Config 의 필드는 클래스를 만들 때 한 번 평가된다. 워커가 기동하면서 정하는
    값(역압·동시 처리·재시도)은 그 시점에 읽어야 하므로 필드로 두지 않고 이
    함수로 받는다. 설정 파일에 적은 값이 반영되는 경로는 하나여야 한다 —
    os.getenv 를 직접 읽으면 운영자가 config-{env}.yml 에 적어도 조용히
    무시된다.
    """
    return _get(key, default, cast)


# ─── 설정 클래스 (기존 API 호환) ──────────────────────────────────────────


class Config:
    """애플리케이션 설정 — file > env > default 우선순위."""

    # Redis 설정 (단일 노드용)
    REDIS_HOST: str = _get("REDIS_HOST", "localhost")
    REDIS_PORT: int = _get("REDIS_PORT", 6379, cast="int")
    REDIS_DB: int = _get("REDIS_DB", 0, cast="int")
    REDIS_PASSWORD: str = _get("REDIS_PASSWORD", "")

    # Redis Cluster 설정 (내부망 운영용)
    # REDIS_CLUSTER_NODES: "host1:port1,host2:port2,..." 또는 yaml 리스트
    # 값이 비어있으면 단일 노드(REDIS_HOST/PORT) 사용, 채워져 있으면 클러스터 모드.
    REDIS_CLUSTER_NODES: str = ""
    _redis_nodes_raw = _flat_lookup(_FILE_CONFIG, "REDIS_CLUSTER_NODES")
    if _redis_nodes_raw is None:
        _redis_nodes_raw = os.getenv("REDIS_CLUSTER_NODES", "")
    if isinstance(_redis_nodes_raw, list):
        REDIS_CLUSTER_NODES = ",".join(str(x) for x in _redis_nodes_raw)
    elif _redis_nodes_raw:
        REDIS_CLUSTER_NODES = str(_redis_nodes_raw)

    @classmethod
    def redis_cluster_node_list(cls) -> list[tuple[str, int]]:
        """REDIS_CLUSTER_NODES 를 (host, port) 튜플 리스트로 파싱."""
        if not cls.REDIS_CLUSTER_NODES:
            return []
        out: list[tuple[str, int]] = []
        for node in cls.REDIS_CLUSTER_NODES.split(","):
            node = node.strip()
            if not node:
                continue
            host, _, port = node.rpartition(":")
            out.append((host or "localhost", int(port or "6379")))
        return out

    @classmethod
    def is_redis_cluster(cls) -> bool:
        return bool(cls.REDIS_CLUSTER_NODES.strip())

    # Redis Stream 설정 (ETL)
    REDIS_ETL_STREAM_NAME: str = _get("REDIS_ETL_STREAM_NAME", "rag:etl:stream")
    REDIS_ETL_RESULT_STREAM_NAME: str = _get("REDIS_ETL_RESULT_STREAM_NAME", "rag:etl:result:stream")
    REDIS_ETL_CONSUMER_GROUP: str = _get("REDIS_ETL_CONSUMER_GROUP", "etl-worker-group")
    REDIS_ETL_CONSUMER_NAME: str = _get("REDIS_ETL_CONSUMER_NAME", "etl-worker-1")

    # Redis Stream 설정 (Chunking)
    REDIS_CHUNK_STREAM_NAME: str = _get("REDIS_CHUNK_STREAM_NAME", "rag:chunk:stream")
    REDIS_CHUNK_RESULT_STREAM_NAME: str = _get("REDIS_CHUNK_RESULT_STREAM_NAME", "rag:chunk:result:stream")
    REDIS_CHUNK_CONSUMER_GROUP: str = _get("REDIS_CHUNK_CONSUMER_GROUP", "chunk-worker-group")
    REDIS_CHUNK_CONSUMER_NAME: str = _get("REDIS_CHUNK_CONSUMER_NAME", "chunk-worker-1")

    # Redis Stream 설정 (Embedding)
    REDIS_EMBED_STREAM_NAME: str = _get("REDIS_EMBED_STREAM_NAME", "rag:embed:stream")
    REDIS_EMBED_RESULT_STREAM_NAME: str = _get("REDIS_EMBED_RESULT_STREAM_NAME", "rag:embed:result:stream")
    REDIS_EMBED_CONSUMER_GROUP: str = _get("REDIS_EMBED_CONSUMER_GROUP", "embed-worker-group")
    REDIS_EMBED_CONSUMER_NAME: str = _get("REDIS_EMBED_CONSUMER_NAME", "embed-worker-1")

    # Redis Stream 설정 (Ontology)
    REDIS_ONTOLOGY_STREAM_NAME: str = _get("REDIS_ONTOLOGY_STREAM_NAME", "rag:ontology:stream")
    REDIS_ONTOLOGY_RESULT_STREAM_NAME: str = _get("REDIS_ONTOLOGY_RESULT_STREAM_NAME", "rag:ontology:result:stream")
    REDIS_ONTOLOGY_CONSUMER_GROUP: str = _get("REDIS_ONTOLOGY_CONSUMER_GROUP", "ontology-worker-group")
    REDIS_ONTOLOGY_CONSUMER_NAME: str = _get("REDIS_ONTOLOGY_CONSUMER_NAME", "ontology-worker-1")

    # Ontology NLP 설정
    ONTOLOGY_EMBEDDING_MODEL: str = _get(
        "ONTOLOGY_EMBEDDING_MODEL",
        "sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2",
    )
    ONTOLOGY_MIN_TERM_FREQ: int = _get("ONTOLOGY_MIN_TERM_FREQ", 2, cast="int")
    ONTOLOGY_MIN_TERM_LENGTH: int = _get("ONTOLOGY_MIN_TERM_LENGTH", 2, cast="int")
    ONTOLOGY_COOCCURRENCE_WINDOW: int = _get("ONTOLOGY_COOCCURRENCE_WINDOW", 3, cast="int")
    ONTOLOGY_MIN_RELATION_CONFIDENCE: float = _get("ONTOLOGY_MIN_RELATION_CONFIDENCE", 0.3, cast="float")
    ONTOLOGY_SIMILARITY_THRESHOLD: float = _get("ONTOLOGY_SIMILARITY_THRESHOLD", 0.85, cast="float")
    ONTOLOGY_GRAPHDB_ENABLED: bool = _get("ONTOLOGY_GRAPHDB_ENABLED", False, cast="bool")

    # LLM 온톨로지 추출 설정
    ONTOLOGY_LLM_ENDPOINT: str = _get("ONTOLOGY_LLM_ENDPOINT", "")
    ONTOLOGY_LLM_MODEL: str = _get("ONTOLOGY_LLM_MODEL", "")
    ONTOLOGY_LLM_API_KEY: str = _get("ONTOLOGY_LLM_API_KEY", "")
    ONTOLOGY_LLM_BATCH_SIZE: int = _get("ONTOLOGY_LLM_BATCH_SIZE", 5, cast="int")

    # Redis Stream 설정 (MRC)
    REDIS_MRC_STREAM_NAME: str = _get("REDIS_MRC_STREAM_NAME", "rag:mrc:stream")
    REDIS_MRC_RESULT_STREAM_NAME: str = _get("REDIS_MRC_RESULT_STREAM_NAME", "rag:mrc:result:stream")
    REDIS_MRC_CONSUMER_GROUP: str = _get("REDIS_MRC_CONSUMER_GROUP", "mrc-worker-group")
    REDIS_MRC_CONSUMER_NAME: str = _get("REDIS_MRC_CONSUMER_NAME", "mrc-worker-1")

    # MRC 설정
    MRC_CONFIDENCE_AUTO_THRESHOLD: float = _get("MRC_CONFIDENCE_AUTO_THRESHOLD", 0.8, cast="float")
    MRC_CONFIDENCE_REVIEW_THRESHOLD: float = _get("MRC_CONFIDENCE_REVIEW_THRESHOLD", 0.6, cast="float")
    MRC_MAX_QUESTIONS_PER_CHUNK: int = _get("MRC_MAX_QUESTIONS_PER_CHUNK", 5, cast="int")

    # Redis Stream 설정 (Connector)
    REDIS_CONNECTOR_STREAM_NAME: str = _get("REDIS_CONNECTOR_STREAM_NAME", "rag:connector:stream")
    REDIS_CONNECTOR_RESULT_STREAM_NAME: str = _get("REDIS_CONNECTOR_RESULT_STREAM_NAME", "rag:connector:result:stream")
    REDIS_CONNECTOR_CONSUMER_GROUP: str = _get("REDIS_CONNECTOR_CONSUMER_GROUP", "connector-worker-group")
    REDIS_CONNECTOR_CONSUMER_NAME: str = _get("REDIS_CONNECTOR_CONSUMER_NAME", "connector-worker-1")

    # Redis Stream 설정 (GraphDB)
    REDIS_GRAPHDB_STREAM_NAME: str = _get("REDIS_GRAPHDB_STREAM_NAME", "rag:graphdb:write")
    REDIS_GRAPHDB_RESULT_STREAM_NAME: str = _get("REDIS_GRAPHDB_RESULT_STREAM_NAME", "rag:graphdb:write:result")
    REDIS_GRAPHDB_CONSUMER_GROUP: str = _get("REDIS_GRAPHDB_CONSUMER_GROUP", "graphdb-worker-group")
    REDIS_GRAPHDB_CONSUMER_NAME: str = _get("REDIS_GRAPHDB_CONSUMER_NAME", "graphdb-worker-1")

    # Java 서버 API
    OMNIAI_SERVER_URL: str = _get("OMNIAI_SERVER_URL", "http://localhost:8096")
    OMNIAI_API_KEY: str = _get("OMNIAI_API_KEY", "")

    # PostgreSQL
    POSTGRES_HOST: str = _get("POSTGRES_HOST", "localhost")
    POSTGRES_PORT: int = _get("POSTGRES_PORT", 5432, cast="int")
    POSTGRES_DB: str = _get("POSTGRES_DB", "omniai")
    POSTGRES_USER: str = _get("POSTGRES_USER", "omniai")
    POSTGRES_PASSWORD: str = _get("POSTGRES_PASSWORD", "omniai")

    @classmethod
    def get_postgres_url(cls) -> str:
        return (
            f"postgresql://{cls.POSTGRES_USER}:{cls.POSTGRES_PASSWORD}"
            f"@{cls.POSTGRES_HOST}:{cls.POSTGRES_PORT}/{cls.POSTGRES_DB}"
        )

    # 스토리지 설정
    STORAGE_TYPE: str = _get("STORAGE_TYPE", "local")
    STORAGE_BASE_PATH: str = _get("STORAGE_BASE_PATH", "./data/uploads")

    # ── Tika (폐쇄망 대응) ─────────────────────────────────────────────────
    # tika-python 은 첫 호출 때 maven 에서 tika-server jar 를 내려받는다.
    # 폐쇄망에서는 실패하므로 아래 중 하나를 쓴다.
    #   1) 이미지에 jar 를 넣고 TIKA_SERVER_JAR 에 "경로"(스킴 없이)를 준다 → 다운로드 안 함
    #      jar 옆에 <jar>.md5 파일도 있어야 서명 검사가 네트워크를 타지 않는다
    #   2) 별도 tika 서버를 두고 TIKA_CLIENT_ONLY=true + TIKA_SERVER_ENDPOINT 를 준다
    #   3) 아예 쓰지 않으려면 TIKA_ENABLED=false (해당 형식은 명확한 오류로 실패)
    TIKA_ENABLED: bool = _get("TIKA_ENABLED", True, cast="bool")
    TIKA_SERVER_JAR: str = _get("TIKA_SERVER_JAR", "")
    TIKA_PATH: str = _get("TIKA_PATH", "")
    TIKA_CLIENT_ONLY: bool = _get("TIKA_CLIENT_ONLY", False, cast="bool")
    TIKA_SERVER_ENDPOINT: str = _get("TIKA_SERVER_ENDPOINT", "")

    STORAGE_S3_BUCKET: str = _get("STORAGE_S3_BUCKET", "")
    STORAGE_S3_ENDPOINT: str = _get("STORAGE_S3_ENDPOINT", "")
    STORAGE_S3_ACCESS_KEY: str = _get("STORAGE_S3_ACCESS_KEY", "")
    STORAGE_S3_SECRET_KEY: str = _get("STORAGE_S3_SECRET_KEY", "")

    # ETL 결과 저장소
    ETL_ARTIFACTS_BASE_PATH: str = _get("ETL_ARTIFACTS_BASE_PATH", "./data/etl_artifacts")
    ETL_ARTIFACTS_S3_BUCKET: str = _get("ETL_ARTIFACTS_S3_BUCKET", "")
    ETL_ARTIFACTS_S3_PREFIX: str = _get("ETL_ARTIFACTS_S3_PREFIX", "etl-artifacts")

    # 워커 설정
    WORKER_BATCH_SIZE: int = _get("WORKER_BATCH_SIZE", 10, cast="int")
    WORKER_POLL_TIMEOUT: int = _get("WORKER_POLL_TIMEOUT", 5, cast="int")
    WORKER_MAX_RETRIES: int = _get("WORKER_MAX_RETRIES", 3, cast="int")

    # 메시지 브로커 설정
    #
    # 이 값만 환경변수를 먼저 본다. 나머지는 파일 > 환경변수 순서다.
    # 브로커는 배포 환경이 정하는 것이지 이미지에 딸려 오는 설정 파일이 정할 게 아니다.
    # 파일에 'kafka' 가 박혀 있어 BROKER_BACKEND=redis 를 줘도 무시되는 일이 있었다
    # (2026-10-05). 파일 값은 환경변수가 없을 때의 기본으로만 쓴다.
    BROKER_BACKEND: str = _get_env_first("BROKER_BACKEND", "redis")
    REDIS_STREAM_MAXLEN: int = _get("REDIS_STREAM_MAXLEN", 10000, cast="int")

    # KAFKA_BOOTSTRAP_SERVERS — YAML 리스트 또는 콤마구분 문자열 둘 다 허용.
    # 어느 쪽이든 confluent-kafka 표준 형식인 콤마구분 문자열로 정규화.
    _kafka_bs_raw = _flat_lookup(_FILE_CONFIG, "KAFKA_BOOTSTRAP_SERVERS")
    if _kafka_bs_raw is None:
        _kafka_bs_raw = os.getenv("KAFKA_BOOTSTRAP_SERVERS") or "localhost:9092"
    if isinstance(_kafka_bs_raw, list):
        KAFKA_BOOTSTRAP_SERVERS: str = ",".join(str(x).strip() for x in _kafka_bs_raw if str(x).strip())
    else:
        KAFKA_BOOTSTRAP_SERVERS: str = str(_kafka_bs_raw)

    # Kafka 보안 설정 (내부망 SASL_PLAINTEXT + SCRAM-SHA-256)
    # PLAINTEXT/SSL/SASL_PLAINTEXT/SASL_SSL
    KAFKA_SECURITY_PROTOCOL: str = _get("KAFKA_SECURITY_PROTOCOL", "PLAINTEXT")
    # PLAIN / SCRAM-SHA-256 / SCRAM-SHA-512 / GSSAPI / OAUTHBEARER
    KAFKA_SASL_MECHANISM: str = _get("KAFKA_SASL_MECHANISM", "")
    KAFKA_SASL_USERNAME: str = _get("KAFKA_SASL_USERNAME", "")
    KAFKA_SASL_PASSWORD: str = _get("KAFKA_SASL_PASSWORD", "")
    # SSL 사용 시 (SASL_SSL/SSL)
    # 사설 CA 인증서 경로 (옵션). 지정하면 librdkafka 가 이 CA 로 broker 인증서 검증.
    KAFKA_SSL_CA_LOCATION: str = _get("KAFKA_SSL_CA_LOCATION", "")
    # 인증서 검증 자체 활성화 여부. 내부망 사설 인증서로 CA 매핑이 곤란할 때 false 로 끔.
    # kafka-python 의 `ssl_cert_reqs=ssl.CERT_NONE` 와 동등.
    KAFKA_SSL_VERIFY: bool = _get("KAFKA_SSL_VERIFY", True, cast="bool")
    # 호스트명 검증 알고리즘. 빈 문자열이면 hostname 검증 끔.
    # kafka-python 의 `ssl_check_hostname=False` 와 동등. 기본 "https".
    KAFKA_SSL_ENDPOINT_IDENTIFICATION_ALGORITHM: str = _get(
        "KAFKA_SSL_ENDPOINT_IDENTIFICATION_ALGORITHM", "https"
    )

    # 한 메시지를 처리하는 동안 poll() 을 다시 부르지 않아도 되는 시간.
    #
    # 워커는 메시지 하나를 받아 문서 한 건을 끝까지 처리한다 — 청크 수천 개 임베딩,
    # 벡터DB 저장, 이전 리비전 정리까지. librdkafka 기본값 5분을 넘기면 브로커가
    # 이 컨슈머를 죽은 것으로 보고 그룹에서 빼 버리고, 그 뒤 commit 이
    # UNKNOWN_MEMBER_ID(25) 로 실패한다. 오프셋이 안 올라가니 같은 메시지가 다시 오고,
    # 다시 5분을 넘기고, 영원히 제자리를 돈다.
    #
    # 기본 1시간. 큰 문서가 이보다 오래 걸리면 더 올린다.
    KAFKA_MAX_POLL_INTERVAL_MS: int = _get("KAFKA_MAX_POLL_INTERVAL_MS", 3600000, cast="int")

    @classmethod
    def kafka_client_config(cls) -> dict:
        """confluent-kafka Producer/Consumer 공통 보안 옵션 dict.

        bootstrap.servers + security.protocol + SASL/SSL 옵션을 모아 반환.
        호출자가 group.id 등은 별도 merge.

        SSL 옵션 매핑 (kafka-python ↔ confluent-kafka):
          ssl_cert_reqs=ssl.CERT_NONE   → enable.ssl.certificate.verification=false
          ssl_check_hostname=False      → ssl.endpoint.identification.algorithm="" (빈값)
          사설 CA 경로 지정             → ssl.ca.location=/path/to/ca.pem
        """
        cfg: dict = {"bootstrap.servers": cls.KAFKA_BOOTSTRAP_SERVERS}
        proto = (cls.KAFKA_SECURITY_PROTOCOL or "PLAINTEXT").upper()
        if proto != "PLAINTEXT":
            cfg["security.protocol"] = proto
        # ── SASL ────────────────────────────────────────────────────────────
        if cls.KAFKA_SASL_MECHANISM:
            cfg["sasl.mechanism"] = cls.KAFKA_SASL_MECHANISM
            if cls.KAFKA_SASL_USERNAME:
                cfg["sasl.username"] = cls.KAFKA_SASL_USERNAME
            if cls.KAFKA_SASL_PASSWORD:
                cfg["sasl.password"] = cls.KAFKA_SASL_PASSWORD
        # ── SSL (SASL_SSL / SSL 모두에 적용) ───────────────────────────────
        if proto.endswith("SSL"):
            if cls.KAFKA_SSL_CA_LOCATION:
                cfg["ssl.ca.location"] = cls.KAFKA_SSL_CA_LOCATION
            # 인증서 검증 OFF — 사설 인증서/자체서명 핸드쉐이크 실패 회피 (dev/내부망)
            if not cls.KAFKA_SSL_VERIFY:
                cfg["enable.ssl.certificate.verification"] = False
            # 호스트명 검증 알고리즘 — 빈 문자열이면 disable
            # librdkafka 기본값 "https" 외 명시 (사이트 운영자가 빈값으로 끄거나 'https' 로 명시)
            algo = cls.KAFKA_SSL_ENDPOINT_IDENTIFICATION_ALGORITHM
            if algo != "https":  # 기본값이면 굳이 보내지 않음
                cfg["ssl.endpoint.identification.algorithm"] = algo
        return cfg

    # 워커 직접 쓰기 토글
    CHUNK_WORKER_GRAPH_PUBLISH: bool = _get("CHUNK_WORKER_GRAPH_PUBLISH", True, cast="bool")
    CHUNK_WORKER_OPENSEARCH_DIRECT: bool = _get("CHUNK_WORKER_OPENSEARCH_DIRECT", True, cast="bool")
    ONTOLOGY_WORKER_GRAPH_PUBLISH: bool = _get("ONTOLOGY_WORKER_GRAPH_PUBLISH", True, cast="bool")

    # ontology_worker 의 PostgreSQL 직접쓰기 폴백 토글.
    # default=False — Oracle 운영 환경에서는 PG 가 없으므로 폴백 비활성이 안전.
    # PG 운영 사이트만 명시적으로 true 설정.
    ONTOLOGY_DIRECT_DB_FALLBACK: bool = _get("ONTOLOGY_DIRECT_DB_FALLBACK", False, cast="bool")

    # 에러 처리
    MAX_RETRIES: int = _get("MAX_RETRIES", 3, cast="int")
    RETRY_DELAY_BASE: int = _get("RETRY_DELAY_BASE", 1, cast="int")
    RETRY_DELAY_MAX: int = _get("RETRY_DELAY_MAX", 60, cast="int")

    # 로깅
    # 브로커와 같은 이유로 환경변수를 먼저 본다. 장애가 났을 때 재배포 없이 올려야 하는데,
    # 이미지에 들어 있는 설정 파일이 이기면 LOG_LEVEL=DEBUG 를 줘도 아무 일도 안 일어난다.
    LOG_LEVEL: str = _get_env_first("LOG_LEVEL", "INFO")
    LOG_FORMAT: str = _get(
        "LOG_FORMAT",
        "<green>{time:YYYY-MM-DD HH:mm:ss}</green> | <level>{level: <8}</level> | <cyan>{name}</cyan>:<cyan>{function}</cyan> - <level>{message}</level>",
    )

    # 모니터링
    METRICS_ENABLED: bool = _get("METRICS_ENABLED", True, cast="bool")
    METRICS_PORT: int = _get("METRICS_PORT", 8000, cast="int")

    # 하트비트
    HEARTBEAT_ENABLED: bool = _get("HEARTBEAT_ENABLED", True, cast="bool")
    HEARTBEAT_INTERVAL: int = _get("HEARTBEAT_INTERVAL", 10, cast="int")
    HEARTBEAT_TTL: int = _get("HEARTBEAT_TTL", 60, cast="int")
    WORKER_VERSION: str = _get("WORKER_VERSION", "1.0.0")

    # 벡터 DB
    VECTORDB_BATCH_SIZE: int = _get("VECTORDB_BATCH_SIZE", 100, cast="int")
    VECTORDB_RETRY_ATTEMPTS: int = _get("VECTORDB_RETRY_ATTEMPTS", 3, cast="int")
    VECTORDB_RETRY_DELAY: int = _get("VECTORDB_RETRY_DELAY", 1, cast="int")

    # 임베딩
    EMBEDDING_BATCH_SIZE: int = _get("EMBEDDING_BATCH_SIZE", 20, cast="int")
    EMBEDDING_MAX_RETRIES: int = _get("EMBEDDING_MAX_RETRIES", 2, cast="int")
    EMBEDDING_RETRY_BASE_DELAY: float = _get("EMBEDDING_RETRY_BASE_DELAY", 1.0, cast="float")
