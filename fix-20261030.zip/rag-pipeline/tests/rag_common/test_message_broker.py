"""
rag_common/message_broker.py 단위 테스트.

Design §9.1의 9개 케이스 + 추가 edge case.
RedisStreamBroker는 실제 Redis 없이 fakeredis 또는 unittest.mock.patch로 검증.
"""

from unittest.mock import MagicMock, patch

import pytest
import redis

from rag_common.broker_factory import create_broker
from rag_common.message_broker import (
    BrokerConsumeError,
    BrokerPublishError,
    KafkaBroker,
    MessageBroker,
    RedisStreamBroker,
)


# ==========================================================
# 1. Serialize (정적 메서드, Redis 연결 불필요)
# ==========================================================

class TestSerialize:
    def test_serialize_none_filter(self):
        """None/빈 문자열 필드 필터링."""
        data = {"a": "1", "b": None, "c": "", "d": "ok"}
        result = RedisStreamBroker._serialize(data)
        assert result == {"a": "1", "d": "ok"}

    def test_serialize_nested_dict(self):
        """dict/list는 JSON 문자열로 변환."""
        data = {"a": {"x": 1}, "b": [1, 2, 3], "c": "plain"}
        result = RedisStreamBroker._serialize(data)
        assert result["a"] == '{"x": 1}'
        assert result["b"] == "[1, 2, 3]"
        assert result["c"] == "plain"

    def test_serialize_numeric(self):
        """숫자는 str로 변환."""
        data = {"count": 5, "ratio": 0.25}
        result = RedisStreamBroker._serialize(data)
        assert result == {"count": "5", "ratio": "0.25"}

    def test_serialize_empty_dict(self):
        """빈 dict는 빈 dict 반환."""
        assert RedisStreamBroker._serialize({}) == {}


# ==========================================================
# 2. Factory
# ==========================================================

class TestFactory:
    def test_factory_redis_default(self):
        """기본 backend는 redis → RedisStreamBroker."""
        with patch("rag_common.message_broker.redis.Redis"):
            broker = create_broker("redis")
            assert isinstance(broker, RedisStreamBroker)

    def test_factory_kafka_returns_kafka_broker(self, monkeypatch):
        """Kafka → KafkaBroker (broker-kafka-migration 실구현 후)."""
        from unittest.mock import MagicMock
        import confluent_kafka
        monkeypatch.setattr(confluent_kafka, "Producer", MagicMock())
        monkeypatch.setattr(confluent_kafka, "Consumer", MagicMock())
        broker = create_broker("kafka")
        assert isinstance(broker, KafkaBroker)

    def test_factory_unknown_backend(self):
        """지원하지 않는 backend는 ValueError."""
        with pytest.raises(ValueError, match="Unknown broker backend"):
            create_broker("rabbitmq")

    def test_factory_case_insensitive(self):
        """backend 이름은 대소문자 무시."""
        with patch("rag_common.message_broker.redis.Redis"):
            broker = create_broker("REDIS")
            assert isinstance(broker, RedisStreamBroker)


# ==========================================================
# 3. RedisStreamBroker (redis client mock)
# ==========================================================

@pytest.fixture
def mock_redis(monkeypatch):
    """rag_common.message_broker.redis.Redis를 mock으로 대체."""
    mock = MagicMock()
    monkeypatch.setattr("rag_common.message_broker.redis.Redis", lambda **kw: mock)
    return mock


class TestRedisStreamBroker:
    def test_ensure_consumer_group_create(self, mock_redis):
        broker = RedisStreamBroker()
        broker.ensure_consumer_group("rag:test:stream", "test-group")
        mock_redis.xgroup_create.assert_called_once_with(
            name="rag:test:stream", groupname="test-group", id="0", mkstream=True
        )

    def test_ensure_consumer_group_busygroup_ignored(self, mock_redis):
        """이미 존재하는 group은 BUSYGROUP 에러 무시."""
        mock_redis.xgroup_create.side_effect = redis.exceptions.ResponseError(
            "BUSYGROUP Consumer Group name already exists"
        )
        broker = RedisStreamBroker()
        # 예외 발생 안 해야 함
        broker.ensure_consumer_group("rag:test:stream", "test-group")

    def test_ensure_consumer_group_other_error_raises(self, mock_redis):
        """BUSYGROUP 아닌 에러는 BrokerConsumeError로 변환."""
        mock_redis.xgroup_create.side_effect = redis.exceptions.ResponseError("other error")
        broker = RedisStreamBroker()
        with pytest.raises(BrokerConsumeError):
            broker.ensure_consumer_group("rag:test:stream", "test-group")

    def test_publish_success(self, mock_redis):
        """publish 성공 시 record_id 반환."""
        mock_redis.xadd.return_value = "1234-0"
        broker = RedisStreamBroker()
        record_id = broker.publish("rag:test:stream", {"task_id": "t1", "text": "hello"})
        assert record_id == "1234-0"
        mock_redis.xadd.assert_called_once()

    def test_publish_failure(self, mock_redis):
        """publish 실패 시 BrokerPublishError."""
        mock_redis.xadd.side_effect = Exception("redis down")
        broker = RedisStreamBroker()
        with pytest.raises(BrokerPublishError) as exc:
            broker.publish("rag:test:stream", {"task_id": "t1"})
        assert exc.value.stream == "rag:test:stream"
        assert "redis down" in exc.value.reason

    def test_send_result_success(self, mock_redis):
        """send_result은 별도 result_stream에 xadd."""
        mock_redis.xadd.return_value = "1234-1"
        broker = RedisStreamBroker()
        record_id = broker.send_result("rag:test:result:stream", {"success": "true"})
        assert record_id == "1234-1"
        # 첫 번째 인자가 result_stream이어야 함
        args, _kw = mock_redis.xadd.call_args
        assert args[0] == "rag:test:result:stream"

    def test_read_message_returns_message(self, mock_redis):
        """read_message가 정상 메시지 반환."""
        mock_redis.xpending_range.return_value = []  # PEL 없음
        mock_redis.xreadgroup.return_value = [
            ("rag:test:stream", [("5678-0", {"task_id": "t1"})])
        ]
        broker = RedisStreamBroker()
        result = broker.read_message("rag:test:stream", "g", "c")
        assert result == ("5678-0", {"task_id": "t1"})

    def test_read_message_timeout_none(self, mock_redis):
        """timeout으로 메시지 없을 때 None 반환."""
        mock_redis.xpending_range.return_value = []
        mock_redis.xreadgroup.return_value = []
        broker = RedisStreamBroker()
        assert broker.read_message("rag:test:stream", "g", "c") is None

    def test_read_message_pel_claim_priority(self, mock_redis):
        """PEL에 stale 메시지가 있으면 우선 반환."""
        mock_redis.xpending_range.return_value = [
            {"message_id": "old-1", "time_since_delivered": 20000, "consumer": "other"}
        ]
        mock_redis.xclaim.return_value = [("old-1", {"task_id": "reclaimed"})]
        broker = RedisStreamBroker()
        result = broker.read_message("rag:test:stream", "g", "c", claim_pending=True)
        assert result == ("old-1", {"task_id": "reclaimed"})
        # 새 메시지 read는 호출 안 됨
        mock_redis.xreadgroup.assert_not_called()

    def test_read_message_connection_error_raises(self, mock_redis):
        """연결 오류 시 BrokerConsumeError."""
        mock_redis.xpending_range.return_value = []
        mock_redis.xreadgroup.side_effect = redis.exceptions.ConnectionError("disconnected")
        broker = RedisStreamBroker()
        with pytest.raises(BrokerConsumeError) as exc:
            broker.read_message("rag:test:stream", "g", "c")
        assert "connection" in exc.value.reason

    def test_ack_success(self, mock_redis):
        """ack는 xack + xdel 호출."""
        broker = RedisStreamBroker()
        broker.ack("rag:test:stream", "g", "1234-0")
        mock_redis.xack.assert_called_once_with("rag:test:stream", "g", "1234-0")
        mock_redis.xdel.assert_called_once_with("rag:test:stream", "1234-0")

    def test_ack_failure_raises(self, mock_redis):
        """ack 실패 시 BrokerConsumeError."""
        mock_redis.xack.side_effect = Exception("ack fail")
        broker = RedisStreamBroker()
        with pytest.raises(BrokerConsumeError):
            broker.ack("rag:test:stream", "g", "1234-0")

    def test_get_stream_info_returns_summary(self, mock_redis):
        """get_stream_info가 length + pending 요약 반환."""
        mock_redis.xlen.return_value = 5
        mock_redis.xpending.return_value = {"pending": 2}
        mock_redis.xpending_range.return_value = [
            {"message_id": "a-1", "consumer": "c1", "time_since_delivered": 1000, "times_delivered": 2}
        ]
        broker = RedisStreamBroker()
        info = broker.get_stream_info("rag:test:stream", "g")
        assert info["length"] == 5
        assert info["pending_count"] == 2
        assert len(info["pending_samples"]) == 1

    def test_close_closes_redis(self, mock_redis):
        broker = RedisStreamBroker()
        broker.close()
        mock_redis.close.assert_called_once()


# ==========================================================
# 4. KafkaBroker
# ==========================================================

class TestKafkaBroker:
    def test_kafka_init_requires_bootstrap(self, monkeypatch):
        """KafkaBroker 초기화 시 confluent_kafka.Producer가 호출되는지."""
        from unittest.mock import MagicMock
        fake_producer = MagicMock()
        fake_consumer = MagicMock()
        import confluent_kafka
        monkeypatch.setattr(confluent_kafka, "Producer", MagicMock(return_value=fake_producer))
        monkeypatch.setattr(confluent_kafka, "Consumer", MagicMock(return_value=fake_consumer))
        broker = KafkaBroker()
        assert broker._bootstrap is not None
        assert broker._producer is fake_producer

    def test_kafka_ensure_consumer_group_noop(self, monkeypatch):
        """Kafka에서는 group이 자동 관리되므로 no-op."""
        from unittest.mock import MagicMock
        import confluent_kafka
        monkeypatch.setattr(confluent_kafka, "Producer", MagicMock())
        monkeypatch.setattr(confluent_kafka, "Consumer", MagicMock())
        broker = KafkaBroker()
        broker.ensure_consumer_group("test:topic", "test-group")  # 예외 없이 완료

    def test_lag_조회도_보안_설정을_그대로_쓴다(self, monkeypatch):
        """AdminClient 만 PLAINTEXT 로 붙으면 SASL 브로커가 연결을 끊는다.

        Producer·Consumer 는 보안 옵션을 받는데 lag 조회용 AdminClient 가 받지
        못하면, 적재는 되는데 역압만 브로커 접속 오류를 끝없이 낸다. 이 경로를
        타는 것은 청킹 워커뿐이라 청킹에서만 증상이 보인다.
        """
        from unittest.mock import MagicMock
        import confluent_kafka
        import confluent_kafka.admin
        from rag_common.config import Config

        monkeypatch.setattr(confluent_kafka, "Producer", MagicMock())
        monkeypatch.setattr(confluent_kafka, "Consumer", MagicMock())
        monkeypatch.setattr(Config, "KAFKA_SECURITY_PROTOCOL", "SASL_PLAINTEXT")
        monkeypatch.setattr(Config, "KAFKA_SASL_MECHANISM", "SCRAM-SHA-256")
        monkeypatch.setattr(Config, "KAFKA_SASL_USERNAME", "userid")
        monkeypatch.setattr(Config, "KAFKA_SASL_PASSWORD", "secret")

        seen: dict = {}

        def fake_admin(cfg):
            seen.update(cfg)
            m = MagicMock()
            m.list_topics.return_value = MagicMock(topics={})
            return m

        monkeypatch.setattr(confluent_kafka.admin, "AdminClient", fake_admin)

        broker = KafkaBroker()
        broker.get_stream_info("rag:embed:stream", "embed-worker-group")

        assert seen.get("security.protocol") == "SASL_PLAINTEXT"
        assert seen.get("sasl.mechanism") == "SCRAM-SHA-256"
        assert seen.get("sasl.username") == "userid"
        assert seen.get("sasl.password") == "secret"
        assert seen.get("bootstrap.servers")


# ==========================================================
# 5. 예외 클래스 속성
# ==========================================================

class TestExceptions:
    def test_publish_error_attributes(self):
        exc = BrokerPublishError("s1", "reason-x")
        assert exc.stream == "s1"
        assert exc.reason == "reason-x"
        assert "PUBLISH_FAIL" in str(exc)

    def test_consume_error_attributes(self):
        exc = BrokerConsumeError("s1", "g1", "reason-y")
        assert exc.stream == "s1"
        assert exc.group == "g1"
        assert exc.reason == "reason-y"
        assert "CONSUME_FAIL" in str(exc)


class TestKafkaLagTopicName:
    """lag 을 물을 때도 토픽 이름을 바꿔야 한다.

    설정의 스트림 이름은 Redis 식이다(``rag:embed:stream``). Kafka 는 토픽 이름에
    ':' 를 못 쓰므로 publish/read/ack 는 모두 '.' 로 바꿔 부른다. 그런데 lag 조회만
    바꾸지 않아, 있는 토픽을 없다고 보고 -1 을 돌려주고 있었다.

    받는 쪽(역압)은 -1 을 "브로커 상태를 못 봤다" 로 보고 통과시킨다. 그래서
    **역압이 Kafka 에서 한 번도 동작하지 않았다.** 아무 에러도 나지 않아,
    건수를 로그로 남기기 전까지 드러나지 않았다.
    """

    def test_콜론_이름으로_물어도_점으로_바꿔_센다(self, monkeypatch):
        from rag_common.message_broker import KafkaBroker

        asked = {}

        class FakeAdmin:
            def __init__(self, cfg):
                pass

            def list_topics(self, topic=None, timeout=None):
                asked["topic"] = topic
                raise RuntimeError("여기까지만 본다")

        monkeypatch.setattr("confluent_kafka.admin.AdminClient", FakeAdmin)

        broker = KafkaBroker.__new__(KafkaBroker)
        broker._bootstrap = "kafka:9092"
        broker._security_cfg = {"bootstrap.servers": "kafka:9092"}
        broker._consumers = {}
        broker._probes = {}

        broker.get_stream_info("rag:embed:stream", "embed-worker-group")

        assert asked["topic"] == "rag.embed.stream", (
            f"':' 가 그대로 넘어갔다: {asked['topic']} — 없는 토픽으로 보여 -1 이 된다")
