# -*- coding: utf-8 -*-
"""임베딩 대기열이 넘치면 청킹을 멈춘다.

임베딩은 외부 서버에 청크를 하나씩 HTTP 로 보낸다. 배치를 받지 않는 서버라 처리량이
`파드 수 ÷ 왕복지연` 으로 고정된다. 청킹은 CPU 작업이라 훨씬 빠르고, 문서가 계속
들어오는 운영이라 대기열에 끝이 없다.

파드를 나누면 CPU 경합은 사라지지만 속도 차는 그대로다. 처리량을 올려도 외부 서버
용량이 천장이라 언젠가 다시 밀린다. 무한 증가를 막으려면 생산 쪽을 멈춰야 한다.

대기열이 상한을 넘으면 청킹이 새 작업을 받지 않고, 하한까지 빠지면 다시 받는다.
두 선을 벌려 두어야 멈췄다 켜졌다를 반복하지 않는다.

기본값은 꺼짐이다. 켜지 않은 곳의 동작이 달라지면 안 된다.
"""
from __future__ import annotations

import time
from typing import Callable, Optional

from loguru import logger

from rag_common.config import get_setting


class EmbedQueueGate:
    """임베딩 대기열 깊이를 보고 청킹을 멈출지 정한다.

    :param high: 이 값을 넘으면 멈춘다. 0 이하면 기능을 쓰지 않는다
    :param low: 여기까지 내려와야 다시 받는다. 0 이거나 high 이상이면 high 의 절반
    :param check_interval_sec: 깊이를 다시 묻기까지의 최소 간격. 조회가 공짜가 아니다
    """

    def __init__(self, high: int, low: int, check_interval_sec: float = 10.0):
        self.high = int(high)
        self.enabled = self.high > 0
        low = int(low)
        self.low = low if 0 < low < self.high else self.high // 2
        self.check_interval_sec = float(check_interval_sec)

        self._paused = False
        self._last_check = 0.0
        self._last_depth: Optional[int] = None
        # 깊이를 돌려주는 함수. 워커가 브로커에 맞는 것을 꽂아 준다.
        self.depth_fn: Optional[Callable[[], Optional[int]]] = None
        # 청킹 대기열 깊이. 판단에는 쓰지 않고 로그에만 쓴다 — 현장에서 "청킹이 왜
        # 안 도나" 를 물을 때 양쪽 숫자가 같이 있어야 설명이 된다.
        self.chunk_depth_fn: Optional[Callable[[], Optional[int]]] = None

    @classmethod
    def from_env(cls) -> "EmbedQueueGate":
        """운영이 정하는 값이라 설정 파일이나 환경변수로 받는다.

        오타가 나도 적재가 멈추면 안 되므로, 읽을 수 없으면 꺼진 것으로 본다.
        """
        def _int(name: str) -> int:
            raw = get_setting(name)
            if raw is None or not str(raw).strip():
                return 0
            try:
                return int(str(raw).strip())
            except ValueError:
                logger.warning(f"{name} 값을 읽을 수 없어 역압을 쓰지 않습니다: {raw}")
                return 0

        interval_raw = get_setting("EMBED_QUEUE_CHECK_INTERVAL_SEC")
        try:
            interval = float(str(interval_raw)) if interval_raw else 10.0
        except ValueError:
            interval = 10.0
        return cls(high=_int("EMBED_QUEUE_HIGH_WATERMARK"),
                   low=_int("EMBED_QUEUE_LOW_WATERMARK"),
                   check_interval_sec=interval)

    def should_pause(self, depth: Optional[int]) -> bool:
        """이 깊이에서 멈춰야 하는가. 깊이를 모르면 통과시킨다.

        한 번 멈추면 하한까지 내려와야 푼다. 상한에서 바로 풀면 진동한다.
        """
        if not self.enabled:
            return False
        if depth is None or depth < 0:
            # 조회 실패를 적재 중단으로 바꾸지 않는다.
            return False
        if self._paused:
            if depth <= self.low:
                logger.info(f"임베딩 대기열이 내려와 청킹을 재개합니다: depth={depth} <= {self.low}")
                self._paused = False
        elif depth > self.high:
            logger.warning(
                f"임베딩 대기열이 상한을 넘어 청킹을 멈춥니다: depth={depth} > {self.high} "
                f"(depth <= {self.low} 이 되면 재개)")
            self._paused = True
        return self._paused

    def paused(self, now: Optional[float] = None) -> bool:
        """깊이를 (간격을 두고) 물어 멈출지 정한다.

        조회가 터져도 통과시킨다. 브로커 상태를 못 봤다고 적재를 세울 이유는 없다.
        """
        if not self.enabled or self.depth_fn is None:
            return False
        now = time.monotonic() if now is None else now
        if now - self._last_check >= self.check_interval_sec:
            self._last_check = now
            try:
                self._last_depth = self.depth_fn()
            except Exception as e:
                logger.warning(f"임베딩 대기열 깊이를 읽지 못했습니다(통과시킵니다): {e}")
                self._last_depth = None
            self._log_depths()
        return self.should_pause(self._last_depth)

    def _log_depths(self) -> None:
        """방금 본 건수를 남긴다.

        상한을 넘나들 때만 찍으면 평소에 얼마나 밀려 있었는지 알 수 없다. 상한·하한
        값을 현장 처리량에 맞춰 정하려면 그 숫자가 있어야 한다. 조회 간격마다 한 줄씩
        이라 양이 많지 않다.

        청킹 쪽 조회가 터지더라도 판단은 계속해야 한다 — 로그를 남기려다 적재를
        세울 이유는 없다.
        """
        chunk_depth: Optional[int] = None
        if self.chunk_depth_fn is not None:
            try:
                chunk_depth = self.chunk_depth_fn()
            except Exception as e:
                logger.debug(f"청킹 대기열 깊이를 읽지 못했습니다(로그에서만 빠집니다): {e}")

        def _fmt(value: Optional[int]) -> str:
            # 못 읽은 것을 비워 두면 연결이 안 된 것과 구별이 안 된다. 조회가
            # 되는지부터 봐야 하므로 "알 수 없음" 이라고 적어 둔다.
            return "알 수 없음" if value is None or value < 0 else f"{value}건"

        chunk = "" if self.chunk_depth_fn is None \
            else f", 청킹 대기={_fmt(chunk_depth)}"
        logger.info(
            f"[역압] 임베딩 대기={_fmt(self._last_depth)}{chunk} "
            f"(상한={self.high}, 하한={self.low}, "
            f"현재={'멈춤' if self._paused else '진행'})")
