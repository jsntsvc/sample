# -*- coding: utf-8 -*-
"""팩 프롬프트 기반 추출 — ONT-14-02.

팩이 선언한 어휘와 프롬프트를 LLM 에 실어 보내고, 응답을 계약 모양으로 되돌린다.
**포트만 쓴다** — `LlmPort` 하나다.

## 정규식으로 파싱하지 않는다

현행은 `re.search(r"\\[.*\\]")` 로 응답에서 JSON 을 긁어낸다. 첫 대괄호부터
마지막까지를 잡으므로, 모델이 설명에 예시 배열을 섞으면 **조용히 그것을 파싱한다.**
여기서는 통째로 JSON 이어야 하고, 아니면 실패로 센다. 코드펜스만 벗긴다 —
모델이 그것을 두르는 것은 흔하고, 그 때문에 실패로 세면 지표가 모델 습관을 잰다.

## 배치 실패가 문서를 죽이지 않는다

`chat_batch` 는 **예외를 던지지 않고** 개별 실패를 결과에 담는다. 한 배치가 죽어도
나머지는 살리고, 실패 건수는 `stats` 에 남아 `status` 판정에 쓰인다.

## 청크 번호는 1부터다

프롬프트가 그렇게 요구한다. 0부터 세면 **근거가 한 칸씩 밀리고**, 그 어긋남은
화면에서 엉뚱한 문장을 가리키는 것으로만 보인다.
"""
from __future__ import annotations

import json
import logging

from ..contract import (
    Chunk,
    Concept,
    EngineTask,
    Evidence,
    ExtractionStats,
    PackView,
    Relation,
)

logger = logging.getLogger(__name__)

__all__ = ["PromptStrategy"]


class PromptStrategy:
    """팩 프롬프트로 개념·관계를 뽑는다."""

    #: 두 축 모두 LLM 이다. `NLP_ONLY` 로는 이 전략을 고를 수 없다(VI9).
    concept_axes = frozenset({"llm"})
    relation_axes = frozenset({"llm"})

    async def extract_concepts(self, task: EngineTask, *, pack: PackView,
                               llm, embedding,
                               stats: ExtractionStats) -> list[Concept]:
        if llm is None or not task.chunks:
            return []

        batches = _batches(task.chunks, task.params.llm_batch_size)
        responses = await self._call(llm, task, pack.concept_prompt,
                                     [_chunk_block(b) for b in batches])

        concepts: list[Concept] = []
        for batch, response in zip(batches, responses):
            stats.concept_batch_total += 1
            entries = _parse(response, stats, "concept")
            if entries is None:
                stats.concept_batch_failed += 1
                continue
            concepts.extend(_to_concepts(entries, batch, stats))
        return _dedupe(concepts)

    async def extract_relations(self, task: EngineTask, *, pack: PackView,
                                concepts: list[Concept], llm,
                                stats: ExtractionStats) -> list[Relation]:
        if llm is None or not concepts:
            # 개념이 없으면 관계도 없다. 빈 목록으로 LLM 을 부르지 않는다.
            return []

        # **상한을 넘으면 나눠 부른다.** 잘라내면 뒤쪽 개념의 관계가 통째로 사라지고,
        # 그 사실이 결과에 드러나지 않는다.
        groups = _batches(concepts, task.params.relation_concept_limit)
        # 본문도 같다. 전 그룹에 같은 앞부분을 주면 **뒤쪽 개념은 자기가 나온
        # 문장을 못 본다** — 실물에서 개념 729 개에 관계 39 건으로 드러났다.
        prompts = [f"{_concept_block(group)}\n\n"
                   f"{_group_text(group, task.chunks, task.params, stats)}"
                   for group in groups]

        responses = await self._call(llm, task, pack.relation_prompt, prompts)

        known = {c.canonical for c in concepts}
        relations: list[Relation] = []
        for response in responses:
            stats.relation_batch_total += 1
            entries = _parse(response, stats, "relation")
            if entries is None:
                stats.relation_batch_failed += 1
                continue
            relations.extend(_to_relations(entries, task.chunks, pack, known, stats))
        return relations

    @staticmethod
    async def _call(llm, task: EngineTask, system: str, prompts: list[str]):
        from omni_adapters.ports.llm import ChatRequest

        requests = [
            ChatRequest(system=system, user=prompt,
                        max_tokens=task.params.llm_max_tokens)
            for prompt in prompts
        ]
        return await llm.chat_batch(
            requests, concurrency=task.params.llm_concurrency)


# ── 파싱 ────────────────────────────────────────────────────
def _parse(response, stats: ExtractionStats, kind: str) -> list | None:
    """응답 → 항목 목록. 실패하면 `None`.

    `chat_batch` 는 실패를 `LlmError` 로 담아 온다 — `content` 가 없다.
    """
    content = getattr(response, "content", None)
    if content is None:
        logger.warning("%s 배치 실패: %s", kind,
                       getattr(response, "message", response))
        return None

    if getattr(response, "finish_reason", None) == "length":
        # **잘렸는데 JSON 파싱은 성공할 수 있다.** 그러면 배치 실패로도 안 잡히고
        # 결과만 조용히 적어진다.
        stats.truncated_responses += 1

    text = _strip_fence(content).strip()
    if not text:
        stats.notes.append(f"{kind} 응답이 비었습니다")
        return None
    try:
        data = json.loads(text)
    except ValueError as e:
        # 정규식으로 긁어내지 않는다 — 설명에 섞인 배열을 파싱하게 된다.
        #
        # **응답의 머리와 꼬리를 같이 남긴다.** 예외 메시지만으로는 조치가 갈리지
        # 않는다: 머리가 JSON 이 아니면 모델이 설명이나 사고를 앞에 붙인 것이고
        # (프롬프트 문제), 머리는 맞는데 꼬리가 끊겼으면 토큰이 모자란 것이다
        # (llm_max_tokens). 현장에서 모든 문서가 파싱 실패인데 원문이 없어 어느
        # 쪽인지 가릴 수 없었다(2026-10-06).
        head = text[:200].replace("\n", "\\n")
        tail = text[-80:].replace("\n", "\\n") if len(text) > 280 else ""
        logger.warning("%s 응답 파싱 실패: %s | 길이 %d | 머리: %s%s",
                       kind, e, len(text), head,
                       f" | 꼬리: {tail}" if tail else "")
        stats.notes.append(
            f"{kind} 응답 파싱 실패({e}) — 길이 {len(text)}자, 머리: {head[:120]}")
        return None
    if not isinstance(data, list):
        # JSON 은 맞지만 배열이 아니다 — 모델이 {"concepts": [...]} 로 감쌌을 때다.
        # 왜 0 건인지 알 수 있어야 한다.
        stats.notes.append(
            f"{kind} 응답이 배열이 아닙니다: {type(data).__name__} "
            f"(키: {list(data)[:5] if isinstance(data, dict) else '-'})")
        return None
    return data


def _strip_fence(text: str) -> str:
    """코드펜스만 벗긴다. 모델이 두르는 것은 흔하고, 그 때문에 실패로 세면
    지표가 모델 습관을 잰다.
    """
    stripped = text.strip()
    if not stripped.startswith("```"):
        return stripped
    lines = stripped.splitlines()
    if len(lines) < 2:
        return stripped
    body = lines[1:]
    if body and body[-1].strip().startswith("```"):
        body = body[:-1]
    return "\n".join(body)


# ── 변환 ────────────────────────────────────────────────────
def _to_concepts(entries: list, batch: list[Chunk],
                 stats: ExtractionStats) -> list[Concept]:
    out: list[Concept] = []
    for entry in entries:
        if not isinstance(entry, dict):
            continue
        term = str(entry.get("term") or "").strip()
        if not term:
            # 한 항목이 이상하다고 배치를 통째로 버리면 **나머지가 같이 사라진다.**
            continue
        chunk_id = _resolve_chunk(entry.get("chunk"), batch, stats)
        out.append(Concept(
            canonical=term,
            # 팩에 없는 타입은 계약 검증(VO2)이 폴백하고 원본을 기록한다.
            concept_type=str(entry.get("type") or "").strip(),
            confidence=_ratio(entry.get("confidence"), 0.8),
            evidence=[Evidence(chunk_id=chunk_id,
                               quote=str(entry.get("quote") or ""),
                               source="llm")],
        ))
    return out


def _to_relations(entries: list, chunks: list[Chunk], pack: PackView,
                  known: set[str], stats: ExtractionStats) -> list[Relation]:
    out: list[Relation] = []
    dropped: list[str] = []
    malformed: list[str] = []
    for entry in entries:
        if not isinstance(entry, dict):
            malformed.append("dict 아님")
            continue
        src = str(entry.get("source") or "").strip()
        dst = str(entry.get("target") or "").strip()
        predicate = str(entry.get("predicate") or "").strip()
        if not (src and dst and predicate):
            # **조용히 버리면 관계 0건의 이유를 알 수 없다.** 실물에서 드러났다 —
            # 팩 프롬프트가 `src`/`dst` 로 적혀 있어 전부 여기로 떨어졌는데,
            # 배치는 성공으로 세어지고 지표에는 아무것도 남지 않았다.
            # 모델이 못 찾은 것인지 파서가 버린 것인지 구분되지 않았다.
            missing = [name for name, value in
                       (("source", src), ("target", dst),
                        ("predicate", predicate)) if not value]
            malformed.append("/".join(missing))
            continue
        if src not in known or dst not in known:
            # 없는 개념을 가리키면 계약 검증(VO1)이 **문서를 통째로** 실패시킨다.
            # 여기서 걸러내는 편이 낫다 — 다만 조용히 버리지는 않는다.
            dropped.append(f"{src}->{dst}")
            continue

        weight, confidence = pack.relation_defaults(predicate)
        out.append(Relation(
            src=src, dst=dst, predicate=predicate,
            weight=weight,
            # 명시값이 있으면 그것을 쓴다. 팩 기본값은 모델이 말하지 않았을 때다.
            confidence=_ratio(entry.get("confidence"), confidence),
            evidence=[Evidence(chunk_id=_resolve_chunk(entry.get("chunk"),
                                                       chunks, stats),
                               quote=str(entry.get("quote") or ""),
                               source="llm")],
        ))

    if malformed:
        # **어느 필드가 빠졌는지** 적는다. 건수만 적으면 프롬프트의 어디를
        # 고쳐야 하는지 알 수 없다.
        counts: dict[str, int] = {}
        for reason in malformed:
            counts[reason] = counts.get(reason, 0) + 1
        detail = ", ".join(f"{reason} 없음 {count}건"
                           for reason, count in sorted(counts.items()))
        stats.notes.append(
            f"필드가 빠져 관계 {len(malformed)}건 제외: {detail}. "
            "프롬프트가 요구하는 필드명이 source·target·predicate 인지 "
            "확인하십시오.")
    if dropped:
        # 조용히 버리면 **관계가 왜 적은지** 알 수 없다.
        stats.notes.append(
            f"개념 목록에 없는 끝점으로 관계 {len(dropped)}건 제외: "
            + ", ".join(dropped[:5]) + (" …" if len(dropped) > 5 else ""))
    return out


def _resolve_chunk(raw, batch: list[Chunk], stats: ExtractionStats) -> str:
    """청크 번호(1부터) → `chunk_id`.

    ONT-05 §4-4 — 없거나 범위를 벗어나면 **배치의 첫 청크로 귀속**하고 센다.
    근거를 지어내는 것이 아니라 "이 배치 안에 있었다" 는 참인 정보로 범위를
    넓히는 것이다. `(0,0)` 처럼 거짓 위치를 만드는 것과 다르다.
    """
    try:
        index = int(raw) - 1
    except (TypeError, ValueError):
        index = -1
    if 0 <= index < len(batch):
        return batch[index].chunk_id
    stats.evidence_fallback_count += 1
    return batch[0].chunk_id


def _dedupe(concepts: list[Concept]) -> list[Concept]:
    """같은 개념이 배치마다 나온다. 중복이면 계약 검증(VO7)이 막는다."""
    seen: dict[str, Concept] = {}
    for concept in concepts:
        existing = seen.get(concept.canonical)
        if existing is None:
            seen[concept.canonical] = concept
            continue
        # 근거는 합친다 — 여러 청크에 나온 개념일수록 근거가 많아야 한다.
        existing.evidence.extend(concept.evidence)
    return list(seen.values())


def _ratio(raw, default: float) -> float:
    try:
        value = float(raw)
    except (TypeError, ValueError):
        return default
    return min(max(value, 0.0), 1.0)


# ── 프롬프트 조립 ────────────────────────────────────────────
def _batches(items: list, size: int) -> list[list]:
    step = max(int(size), 1)
    return [items[i:i + step] for i in range(0, len(items), step)]


def _chunk_block(chunks: list[Chunk]) -> str:
    """**번호는 1부터.** 프롬프트가 그렇게 요구한다."""
    return "\n\n".join(f"[{index}] {chunk.text}"
                       for index, chunk in enumerate(chunks, start=1))


def _group_text(group: list[Concept], chunks: list[Chunk],
                params, stats: ExtractionStats) -> str:
    """이 그룹의 개념이 **실제로 나온 청크**만 골라 준다.

    ## 왜 앞부분을 주면 안 되나

    개념은 상한을 넘으면 그룹으로 나눠 부르는데, 본문을 전 그룹에 똑같이
    앞 N 자로 주면 **뒤쪽 그룹은 자기 개념이 나온 문장을 한 줄도 못 본다.**
    모델은 근거가 없으니 관계를 못 만들고, 그 사실은 지표에 남지 않는다 —
    "관계가 원래 적은 문서" 로 보인다.

    실물에서 51 청크 35,191 자 문서가 개념 729 개에 관계 39 건을 냈다.
    19 개 그룹 전부가 같은 앞 3,000 자(문서의 8.5%)를 보고 있었다.

    ## 번호는 전역이다

    `_resolve_chunk` 가 모델이 답한 번호를 **전체 청크 목록**에서 찾는다.
    부분만 준다고 1 부터 다시 매기면 근거가 엉뚱한 청크를 가리킨다.

    ## 근거가 없으면 앞부분으로 때우지 않는다

    어느 본문을 줘야 할지 모르는 것이고, 아무 문장이나 주면 **관계가 그
    문장에서 나온다.** 없으면 없다고 적는다.
    """
    wanted: list[int] = []
    missing: list[str] = []
    index_of = {chunk.chunk_id: i for i, chunk in enumerate(chunks)}
    for concept in group:
        ids = [e.chunk_id for e in concept.evidence if e.chunk_id]
        if not ids:
            missing.append(concept.canonical)
            continue
        for chunk_id in ids:
            position = index_of.get(chunk_id)
            if position is not None and position not in wanted:
                wanted.append(position)

    if missing:
        stats.notes.append(
            f"근거가 없어 본문을 고를 수 없는 개념 {len(missing)}건: "
            + ", ".join(missing[:5]) + (" …" if len(missing) > 5 else ""))

    # 문서 순서로 준다. 뽑힌 순서로 주면 앞뒤가 뒤섞여 모델이 인과를 뒤집는다.
    wanted.sort()
    parts, used, truncated = [], 0, False
    for position in wanted:
        block = f"[{position + 1}] {chunks[position].text}"
        if used + len(block) > params.relation_chunk_chars and parts:
            truncated = True
            break
        parts.append(block)
        used += len(block) + 2

    if truncated:
        # 잘린 것을 안 적으면 **관계가 왜 적은지** 알 수 없다.
        stats.notes.append(
            f"본문 상한({params.relation_chunk_chars}자)에 걸려 청크 "
            f"{len(wanted) - len(parts)}개를 관계 추출에서 제외했습니다. "
            "relation_chunk_chars 를 늘리거나 relation_concept_limit 을 "
            "줄이십시오.")
    return "\n\n".join(parts)


def _concept_block(concepts: list[Concept]) -> str:
    names = ", ".join(c.canonical for c in concepts)
    return f"개념 목록: {names}"
