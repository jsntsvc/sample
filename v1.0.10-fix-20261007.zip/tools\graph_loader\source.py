# -*- coding: utf-8 -*-
"""블로그·메신저 덤프 → 문서·청크 (범용 — 설계 원형은 ONT-19 v3 §4).

## 원천은 chunk_id 에 실린다

엔진 계약의 `Evidence.source` 는 nlp/llm 뿐이다 — 블로그인지 메신저인지, 어느
글·어느 스레드인지는 엔진이 모른다(호스트 개념이다). 그래서 **chunk_id 접두어**로
싣는다:

    blog:<post_id>:c001
    msg:<channel>:<thread_key>:c001

서버는 접두어를 읽어 답변의 근거에 원천을 표시한다. 계약을 오염시키지 않고
원천을 나르는 방법이 이것뿐이다.

## 메신저는 스레드가 청크다

메시지 한 줄은 문장이 아니다. 답글 스레드(`thread_id`)가 있으면 그것, 없으면
시간 간격으로 대화 묶음을 자른다. **청크가 메시지 중간을 자르지 않는다** —
근거 위치가 메시지 경계를 넘으면 사람이 원문을 못 찾는다.

## 필드가 빠지면 멈춘다

`body` 없는 글, `ts` 없는 메시지를 조용히 건너뛰면 "왜 그 글이 그래프에 없나"
를 아무도 모른다. 덤프 형식이 다르면 여기서 죽는 것이 맞다.
"""
from __future__ import annotations

import json
import pathlib
import re
from dataclasses import dataclass, field
from datetime import datetime, timedelta

__all__ = ["SourceDoc", "load_blog", "load_messenger", "group_threads",
           "pack_paragraphs"]


def _reject_duplicates(docs: list["SourceDoc"], where: str) -> None:
    """id 정규화(`_safe`)가 서로 다른 원본을 같은 id 로 접으면 **멈춘다.**

    '#설비운영' 과 '@설비운영' 이 같은 id 가 되면 뒤 문서의 추출·선별 결과가
    앞 것을 조용히 덮어쓴다 — 그래프에서 글 하나가 사라지는데 아무도 모른다.
    """
    seen: dict[str, str] = {}
    for doc in docs:
        if doc.doc_id in seen:
            raise ValueError(
                f"{where}: 문서 id 충돌 '{doc.doc_id}' — {seen[doc.doc_id]!r} 와 "
                f"{doc.locator!r} 가 같은 id 로 정규화됩니다. 원본 id 를 구분되게 하십시오")
        seen[doc.doc_id] = doc.locator

_ID_UNSAFE = re.compile(r"[^0-9A-Za-z가-힣_\-]")


@dataclass
class SourceDoc:
    """원천 문서 하나 — 블로그 글 또는 메신저 스레드."""

    doc_id: str
    kind: str                      # "blog" | "msg"
    title: str
    author: str
    when: str                      # ISO 문자열 (없으면 "")
    locator: str                   # 글 URL 또는 "채널/스레드"
    chunks: list[dict] = field(default_factory=list)
    """`{chunk_id, text, char_start, char_end}` — 엔진 `Chunk` 와 같은 키."""

    def as_dict(self) -> dict:
        return {"doc_id": self.doc_id, "kind": self.kind, "title": self.title,
                "author": self.author, "when": self.when,
                "locator": self.locator, "chunks": self.chunks}

    @staticmethod
    def from_dict(raw: dict) -> "SourceDoc":
        return SourceDoc(raw["doc_id"], raw["kind"], raw["title"], raw["author"],
                         raw.get("when", ""), raw.get("locator", ""),
                         list(raw.get("chunks", [])))


def _safe(value: str) -> str:
    return _ID_UNSAFE.sub("_", str(value))


def _read_items(path: pathlib.Path) -> list:
    """JSON 배열 또는 JSONL(한 줄 = 한 건) — 대용량은 JSONL 로 온다.

    깨진 줄은 **줄 번호와 함께 멈춘다** — 조용히 건너뛰면 그 건이 왜 그래프에
    없는지 아무도 모른다.
    """
    path = pathlib.Path(path)
    text = path.read_text(encoding="utf-8")
    if path.suffix.lower() == ".jsonl" or not text.lstrip().startswith("["):
        items = []
        for lineno, line in enumerate(text.splitlines(), 1):
            if not line.strip():
                continue
            try:
                items.append(json.loads(line))
            except json.JSONDecodeError as exc:
                # 깨진 줄 하나로 수천 건 적재를 세우지 않는다. 줄 번호를 밝혀
                # 알리고 넘어간다 — 조용히 빠뜨리지만 않으면 된다.
                print(f"  [경고] {path}#L{lineno}: JSONL 줄이 깨졌습니다 (건너뜀) — {exc}")
        return items
    parsed = json.loads(text)
    if not isinstance(parsed, list):
        raise ValueError(f"{path}: 최상위가 배열(또는 JSONL)이어야 합니다")
    return parsed


def _require(item: dict, key: str, where: str) -> object:
    if key not in item or item[key] in (None, ""):
        raise ValueError(f"{where}: 필수 필드 '{key}' 가 없습니다 — {item!r:.120}")
    return item[key]


# ── 블로그 ──────────────────────────────────────────────────
def pack_paragraphs(text: str, *, max_chars: int, prefix: str) -> list[dict]:
    """문단을 상한까지 묶는다. 오프셋은 원문 기준 — 근거를 원문에서 찾기 위해."""
    if max_chars <= 0:
        raise ValueError("max_chars 는 양수여야 합니다")
    chunks: list[dict] = []
    buffer: list[tuple[int, str]] = []   # (원문 오프셋, 문단)

    def flush() -> None:
        if not buffer:
            return
        start = buffer[0][0]
        end = buffer[-1][0] + len(buffer[-1][1])
        chunks.append({"chunk_id": f"{prefix}:c{len(chunks) + 1:03d}",
                       "text": text[start:end], "char_start": start,
                       "char_end": end})
        buffer.clear()

    for match in re.finditer(r"[^\n]+(?:\n(?!\s*\n)[^\n]+)*", text):
        para = match.group(0)
        if not para.strip():
            continue
        used = sum(len(p) for _, p in buffer)
        if buffer and used + len(para) > max_chars:
            flush()
        buffer.append((match.start(), para))
        if len(para) > max_chars:
            # 한 문단이 상한보다 크면 그대로 한 청크 — 문단 중간을 자르지 않는다.
            flush()
    flush()
    return chunks


def load_blog(path: pathlib.Path, *, max_chars: int) -> list[SourceDoc]:
    """`[{id, title, body, author, created_at, url}]` → 글마다 SourceDoc."""
    posts = _read_items(pathlib.Path(path))
    docs: list[SourceDoc] = []
    skipped = 0
    no_id = 0
    with_body = 0          # 본문이 있는 레코드 수 — 0 이면 변환 설정이 틀린 것이다
    for i, post in enumerate(posts):
        # id 가 없으면 청크 id(`blog:<키>:cNNN`)를 만들 수 없고, 연결(linker)이
        # 어느 글에서 나왔는지 되찾지 못한다. 그 한 건만 빠지면 된다 — 세고 넘어간다.
        post_id = str(post.get("id") or "").strip()
        if not post_id:
            no_id += 1
            continue
        post_id = _safe(post_id)
        # **본문이 없는 글은 건너뛴다. 멈추지 않는다.**
        #
        # `csv2jsonl` 은 값이 비면 **키를 넣지 않는다**(`if value: out[field] = value`).
        # 그래서 DESC_CTN 이 빈 업무는 `body` 키가 아예 없다 — 키의 유무로는 변환 설정
        # 오류와 빈 데이터를 **가릴 수 없다.** 처음에 키가 없으면 오류로 봤다가 현장에서
        # 같은 실패가 다시 났다(2026-10-05).
        #
        # 제목만 있는 글은 **뽑을 것이 없다.** 제목으로 개념을 뽑으면 근거 없는 개념이
        # 생겨 검색 품질을 떨어뜨린다. 세고 건너뛴다.
        #
        # CRLF 덤프는 \r 이 문단 끝에 남는다 — 오프셋은 정규화된 본문 기준이다.
        body = str(post.get("body") or "").replace("\r\n", "\n").strip()
        title = str(post.get("title") or "").strip()
        if not body:
            skipped += 1
            continue
        with_body += 1
        text = f"{title}\n\n{body}" if title else body
        docs.append(SourceDoc(
            doc_id=f"blog:{post_id}", kind="blog", title=title,
            author=str(post.get("author", "")),
            when=str(post.get("created_at", "")),
            locator=str(post.get("url", "")),
            chunks=pack_paragraphs(text, max_chars=max_chars,
                                   prefix=f"blog:{post_id}")))
    if skipped:
        # 조용히 빠뜨리지 않는다 — 개념 수가 적은 이유를 알 수 있어야 한다.
        print(f"  건너뜀 {skipped}건: 본문이 빈 글 ({path})")
    if no_id:
        print(f"  건너뜀 {no_id}건: id 가 없는 글 ({path})")
    # **전부 본문이 없어도 멈추지 않는다.** 한 건도 본문이 없으면 거의 언제나
    # `field_map` 에 body 매핑이 빠진 것이지만, 그 판단으로 적재 전체를 세우면
    # 나머지 원천까지 못 올린다. 크게 알리고 넘어간다 — 중간에 멈추는 것보다
    # 경고를 보고 다시 올리는 쪽이 낫다.
    if posts and not with_body:
        print(f"  [경고] {path}: 본문이 있는 글이 한 건도 없습니다 "
              f"({len(posts)}건 모두 비었습니다) — 변환 설정(csv2jsonl 의 field_map)에 "
              f"body 매핑이 있는지 확인하십시오.")
    _reject_duplicates(docs, str(path))
    return docs


# ── 메신저 ──────────────────────────────────────────────────
def _ts(value: object, where: str) -> datetime:
    try:
        return datetime.fromisoformat(str(value))
    except ValueError as exc:
        raise ValueError(f"{where}: ts 가 ISO 형식이 아닙니다: {value!r}") from exc


def group_threads(messages: list[dict], *, gap_minutes: int) -> list[list[dict]]:
    """채널별로, `thread_id` 가 있으면 그것으로, 없으면 시간 간격으로 묶는다.

    두 규칙을 **섞지 않는다** — thread_id 가 있는 메시지를 시간으로 다시 자르면
    답글 스레드가 둘로 갈린다.
    """
    by_channel: dict[str, list[dict]] = {}
    empty_text = 0
    bad_field = 0
    for i, msg in enumerate(messages):
        # channel·msg_id·ts 없이는 스레드를 묶거나 청크 id 를 만들 수 없다. 그
        # 메시지 하나만 빠지면 된다 — 세고 넘어간다(한 건으로 적재를 세우지 않는다).
        channel = str(msg.get("channel") or "").strip()
        if not channel or not str(msg.get("msg_id") or "").strip():
            bad_field += 1
            continue
        try:
            _ts(msg.get("ts"), f"message#{i}")
        except ValueError:
            bad_field += 1
            continue
        # 글 쪽과 같다: 본문이 빈 메시지는 `작성자: ` 한 줄이 되어 추출할 것이
        # 없다. `csv2jsonl` 이 빈 값의 키를 넣지 않으므로 키의 유무로는 설정
        # 오류와 빈 데이터를 가릴 수 없다 — 전부 비었는지는 루프 뒤에서 본다.
        if not str(msg.get("text") or "").strip():
            empty_text += 1
            continue
        by_channel.setdefault(channel, []).append(msg)
    # 전부 비어도 멈추지 않는다 — 글 쪽과 같이 경고만 낸다.
    if messages and not by_channel:
        print(f"  [경고] 본문이 있는 메시지가 한 건도 없습니다 "
              f"({len(messages)}건 모두 비었습니다) — 변환 설정(csv2jsonl 의 field_map)에 "
              f"text 매핑이 있는지 확인하십시오.")
    if empty_text:
        # 조용히 빠뜨리지 않는다 — 대화 수가 적은 이유를 알 수 있어야 한다.
        print(f"  건너뜀 {empty_text}건: 본문이 빈 메시지")
    if bad_field:
        print(f"  건너뜀 {bad_field}건: channel·msg_id·ts 가 없거나 깨진 메시지")

    threads: list[list[dict]] = []
    gap = timedelta(minutes=gap_minutes)
    for channel, items in by_channel.items():
        items.sort(key=lambda m: (_ts(m["ts"], "sort"), str(m["msg_id"])))
        explicit: dict[str, list[dict]] = {}
        current: list[dict] = []
        last: datetime | None = None
        for msg in items:
            if msg.get("thread_id"):
                explicit.setdefault(str(msg["thread_id"]), []).append(msg)
                continue
            now = _ts(msg["ts"], "gap")
            if current and last is not None and now - last > gap:
                threads.append(current)
                current = []
            current.append(msg)
            last = now
        if current:
            threads.append(current)
        threads.extend(explicit.values())
    return threads


def _thread_key(thread: list[dict]) -> str:
    first = thread[0]
    if first.get("thread_id"):
        return f"t{_safe(first['thread_id'])}"
    return "g" + _ts(first["ts"], "key").strftime("%Y%m%d-%H%M")


def load_messenger(path: pathlib.Path, *, max_chars: int,
                   gap_minutes: int) -> list[SourceDoc]:
    """`[{channel, thread_id?, msg_id, author, ts, text}]` → 스레드마다 SourceDoc.

    청크 텍스트는 `작성자: 본문` 줄의 묶음이고, **메시지 경계에서만** 자른다.
    """
    messages = _read_items(pathlib.Path(path))
    docs: list[SourceDoc] = []
    for thread in group_threads(messages, gap_minutes=gap_minutes):
        channel = _safe(thread[0]["channel"])
        key = _thread_key(thread)
        prefix = f"msg:{channel}:{key}"
        lines = [f"{m.get('author', '?')}: {str(m['text']).replace(chr(13), '')}"
                 for m in thread]

        chunks: list[dict] = []
        buffer: list[str] = []
        buffered = 0          # 누적 길이 — 줄마다 다시 세면 긴 스레드에서 O(n²)
        offset = 0
        start = 0

        def flush() -> None:
            nonlocal buffer, buffered, start
            if not buffer:
                return
            text = "\n".join(buffer)
            chunks.append({"chunk_id": f"{prefix}:c{len(chunks) + 1:03d}",
                           "text": text, "char_start": start,
                           "char_end": start + len(text)})
            buffer = []
            buffered = 0

        for line in lines:
            if buffer and buffered + len(line) > max_chars:
                flush()
                start = offset
            buffer.append(line)
            buffered += len(line) + 1
            offset += len(line) + 1
        flush()

        authors = sorted({str(m.get("author", "")) for m in thread if m.get("author")})
        docs.append(SourceDoc(
            doc_id=prefix, kind="msg",
            title=thread[0]["text"][:60],
            author=", ".join(authors),
            when=str(thread[0]["ts"]),
            locator=f"{thread[0]['channel']}/{key}",
            chunks=chunks))
    _reject_duplicates(docs, str(path))
    return docs
