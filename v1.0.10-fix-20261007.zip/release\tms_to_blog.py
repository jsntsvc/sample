# -*- coding: utf-8 -*-
"""TMS 업무 JSONL → graph_loader --blog 형식.

    python /opt/release/tms_to_blog.py /data/jsonl /data/jsonl/tms_as_blog.jsonl

graph_loader 의 블로그 입력은 {id, title, body, author, created_at, url} 이다. TMS 는
key 라 id 가 없다.

## 본문에 문맥을 싣는다 (2026-10-05 현장)

예전에는 `title` 과 `body` 만 넘겼다. `csv2jsonl` 의 tms_task 가 뽑는 공간·분류·라벨·
담당자·연관업무가 **전부 버려져서**, LLM 이 개념을 뽑을 때 **이 업무가 어느 공간·어느
범주의 것인지 몰랐다.** 같은 말이 다른 공간에서 다른 뜻인데 하나의 개념으로 뭉친다
(사전에 `BIZDATAVOC,원본 data 다운로드` 가 잘못 들어갔던 것과 같은 성질이다).

그래서 머리말로 싣는다. **본문 앞에 둔다** — 뒤에 두면 긴 업무에서 마지막 청크에만
들어가 대부분의 개념이 문맥 없이 추출된다. 짧게 한 줄씩 적어 첫 청크만 차지한다.

## author 가 비어 있던 것

변환이 `reporter`(단수)를 찾았는데 tms_task 는 `reporters`(배열)를 만든다. `url` 과
`comments` 도 만들지 않는다(처리내역은 DESC_CTN 하나뿐이다 — tms_task.yaml 참고).
그래서 author 가 **항상 빈 문자열**이었고, 빈 author 는 엔진의 `derive_discussed` 가
`if not author: return [], []` 로 걸러 **작성자→개념 연결이 0건**이었다.
요청자 첫 사람을, 없으면 담당자 첫 사람을 쓴다.
"""
import glob
import io
import json
import os
import sys

#: 읽을 파일 이름. csv2jsonl 의 tms_task 설정이 tms_tasks_*.jsonl 을 만든다.
#: tms_issues_* 는 확정 컬럼 이전의 이름이다 - 먼저 만든 JSONL 이 남아 있을 수 있어
#: 둘 다 본다. 이름 하나만 보다가 TMS 본문이 개념층 추출에서 통째로 빠졌다
#: (2026-09-23 배포판 E2E 에서 실측: "TMS 이슈 0건" 이 조용히 지나갔다).
PATTERNS = ("tms_tasks_*.jsonl", "tms_issues_*.jsonl")

#: 머리말에 실을 것 — (JSONL 키, 붙일 이름). 값이 비면 그 줄은 넣지 않는다.
SINGLE_FIELDS = (("space", "업무공간"), ("category", "분류"), ("label", "라벨"))
LIST_FIELDS = (("assignees", "담당"), ("reporters", "요청"))


def _texts(value) -> list[str]:
    """값을 문자열 목록으로. 빈 값·공백뿐인 값은 버린다."""
    if value is None:
        return []
    items = value if isinstance(value, (list, tuple)) else [value]
    return [str(v).strip() for v in items if v is not None and str(v).strip()]


def _head(row: dict) -> str:
    """업무의 문맥 머리말. 실을 것이 없으면 빈 문자열."""
    lines = []
    for key, label in SINGLE_FIELDS:
        values = _texts(row.get(key))
        if values:
            lines.append(f"{label}: {values[0]}")
    for key, label in LIST_FIELDS:
        values = _texts(row.get(key))
        if values:
            lines.append(f"{label}: {', '.join(values)}")
    # 연관 업무는 키로 온다. 본문에 키가 있으면 linker 의 key_mention 이 그것을 잇는다 -
    # 업무끼리의 연결을 개념층에서도 따라갈 수 있게 된다.
    related = _texts(row.get("blocks")) + _texts(row.get("derived_from"))
    if related:
        lines.append(f"연관 업무: {', '.join(related)}")
    return "\n".join(lines)


def _author(row: dict) -> str:
    """작성자 사번. 요청자 우선, 없으면 담당자.

    비워 두면 엔진이 작성자→개념 연결을 만들지 않는다. 사람으로 묻는 질문이
    근거를 찾지 못하는 원인이 된다.
    """
    for key in ("reporters", "assignees"):
        people = _texts(row.get(key))
        if people:
            return people[0]
    return ""


def _comments(row: dict) -> list[str]:
    """댓글. tms_task 는 만들지 않지만 다른 원천이 주면 싣는다.

    발화자·시각을 접두사로 남긴다 — 없으면 조치·결정 추출이 흐려진다(가이드 05장).
    """
    out = []
    for c in row.get("comments") or []:
        text = str(c.get("text") or "").strip()
        if not text:
            continue
        who = str(c.get("author") or "").strip()
        when = str(c.get("ts") or "").strip()
        out.append(f"[댓글 {who} {when}] {text}".replace("[댓글  ] ", "[댓글] "))
    return out


def convert(jsonl_dir: str, out_path: str) -> int:
    count = 0
    empty = 0
    with io.open(out_path, "w", encoding="utf-8") as out:
        paths = []
        for pattern in PATTERNS:
            paths.extend(glob.glob(os.path.join(jsonl_dir, pattern)))
        for path in sorted(set(paths)):
            for line in io.open(path, encoding="utf-8"):
                if not line.strip():
                    continue
                row = json.loads(line)
                key = str(row.get("key") or "").strip()
                if not key:
                    # 키가 없으면 청크 id(`blog:<키>:cNNN`)를 만들 수 없고, linker 가
                    # 어느 업무에서 나왔는지 되찾지 못한다. 세고 건너뛴다.
                    empty += 1
                    continue
                # **머리말은 내용이 아니다.** 공간·분류·담당만 있는 업무는 거기서
                # 나올 개념이 공간 이름뿐이고 그것은 이미 업무 그래프에 있다.
                # 그래서 실제 내용(처리내역·댓글)의 유무로만 판정한다.
                content = [str(row.get("body") or "").strip(), *_comments(row)]
                if not any(content):
                    # 제목만 있는 업무가 현장에 있다. 제목을 본문으로 쓰면 근거 없는
                    # 개념이 생겨 검색 품질을 떨어뜨린다 - 세고 건너뛴다.
                    empty += 1
                    continue
                body = "\n\n".join(p for p in [_head(row), *content] if p)
                out.write(json.dumps({
                    "id": key,
                    "title": str(row.get("title") or "").strip(),
                    "body": body,
                    "author": _author(row),
                    "created_at": str(row.get("created_at") or ""),
                    "url": str(row.get("url") or "")}, ensure_ascii=False) + "\n")
                count += 1
    if empty:
        # 조용히 빠뜨리지 않는다 - 개념 수가 적은 이유를 알 수 있어야 한다.
        print(f"  건너뜀 {empty}건 (키가 없거나 제목·본문이 모두 빈 업무)")
    return count


if __name__ == "__main__":
    if len(sys.argv) != 3:
        raise SystemExit("사용법: tms_to_blog.py <jsonl 폴더> <출력 파일>")
    n = convert(sys.argv[1], sys.argv[2])
    print(f"TMS 업무 {n}건 → {sys.argv[2]}")
    if n == 0:
        # 0 건은 거의 언제나 파일 이름이 안 맞는 것이다. 조용히 넘어가면 업무 본문이
        # 없는 채로 개념층이 만들어지고, 검증 단계에 가서야 근거 0건으로 드러난다.
        raise SystemExit(
            f"[ERROR] {sys.argv[1]} 에서 TMS 업무 JSONL 을 찾지 못했습니다 "
            f"(찾은 이름: {', '.join(PATTERNS)}). 03장의 csv2jsonl --config tms_task 를 "
            "먼저 실행했는지 확인하십시오.")
