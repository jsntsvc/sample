# -*- coding: utf-8 -*-
"""역압·동시처리·재시도 값을 설정 파일로 줄 수 있어야 한다.

이 배포판은 `config/config-{env}.yml` 로 사이트별 값을 주입한다. K8s 환경변수를
넣을 수 없는 현장이 있어 파일이 환경변수를 이기는 순서로 되어 있다
(rag_common.config 머리말).

그런데 이 세 가지는 `os.getenv` 를 직접 읽어 설정 파일에 적어도 반영되지 않았다.
운영자가 파일에 적고 안 된다고 하는 일이 생긴다 — 청크 암호화 키에서 이미 한 번
겪은 함정이다.

환경변수도 계속 받아야 한다. 이미 그렇게 주고 있는 곳이 있다.
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

import rag_common.config as cfg  # noqa: E402
from rag_common.backpressure import EmbedQueueGate  # noqa: E402
from rag_common.embed_retry import RetryPolicy  # noqa: E402
from rag_common.worker_pump import MessagePump  # noqa: E402


def _pump(**kwargs):
    """스레드 수만 보는 펌프. 브로커는 쓰지 않는다."""
    return MessagePump.from_env(
        broker=object(), stream="s", group="g", consumer="c",
        handler=lambda message_id, data: None, **kwargs)


class TestBackpressure:
    def test_설정_파일로_켠다(self, monkeypatch):
        monkeypatch.setitem(cfg._FILE_CONFIG, "EMBED_QUEUE_HIGH_WATERMARK", 20000)
        monkeypatch.setitem(cfg._FILE_CONFIG, "EMBED_QUEUE_LOW_WATERMARK", 5000)
        monkeypatch.setitem(cfg._FILE_CONFIG, "EMBED_QUEUE_CHECK_INTERVAL_SEC", 30)
        g = EmbedQueueGate.from_env()
        assert g.enabled and g.high == 20000 and g.low == 5000
        assert g.check_interval_sec == 30.0

    def test_설정_파일이_환경변수를_이긴다(self, monkeypatch):
        """이미지에 들어간 파일이 사이트의 값이다."""
        monkeypatch.setenv("EMBED_QUEUE_HIGH_WATERMARK", "100")
        monkeypatch.setitem(cfg._FILE_CONFIG, "EMBED_QUEUE_HIGH_WATERMARK", 20000)
        assert EmbedQueueGate.from_env().high == 20000

    def test_환경변수도_계속_받는다(self, monkeypatch):
        monkeypatch.delitem(cfg._FILE_CONFIG, "EMBED_QUEUE_HIGH_WATERMARK", raising=False)
        monkeypatch.setenv("EMBED_QUEUE_HIGH_WATERMARK", "7000")
        assert EmbedQueueGate.from_env().high == 7000

    def test_파일에_이상한_값이_있으면_꺼진_것으로_본다(self, monkeypatch):
        monkeypatch.setitem(cfg._FILE_CONFIG, "EMBED_QUEUE_HIGH_WATERMARK", "많이")
        assert EmbedQueueGate.from_env().enabled is False


class TestThreads:
    def test_설정_파일로_스레드를_올린다(self, monkeypatch):
        monkeypatch.setitem(cfg._FILE_CONFIG, "EMBED_WORKER_THREADS", 8)
        p = _pump(threads_var="EMBED_WORKER_THREADS", factor_var="EMBED_WORKER_QUEUE_FACTOR")
        assert p.threads == 8
        assert p.queue_limit == 16, "주지 않은 factor 는 2 그대로"

    def test_설정_파일로_큐_배수도_준다(self, monkeypatch):
        monkeypatch.setitem(cfg._FILE_CONFIG, "EMBED_WORKER_THREADS", 4)
        monkeypatch.setitem(cfg._FILE_CONFIG, "EMBED_WORKER_QUEUE_FACTOR", 3)
        assert _pump(threads_var="EMBED_WORKER_THREADS",
                     factor_var="EMBED_WORKER_QUEUE_FACTOR").queue_limit == 12

    def test_설정_파일이_환경변수를_이긴다(self, monkeypatch):
        monkeypatch.setenv("CHUNK_WORKER_THREADS", "16")
        monkeypatch.setitem(cfg._FILE_CONFIG, "CHUNK_WORKER_THREADS", 1)
        assert _pump(threads_var="CHUNK_WORKER_THREADS",
                     factor_var="CHUNK_WORKER_QUEUE_FACTOR").threads == 1

    def test_아무것도_없으면_한_건씩(self, monkeypatch):
        monkeypatch.delitem(cfg._FILE_CONFIG, "ETL_WORKER_THREADS", raising=False)
        monkeypatch.delenv("ETL_WORKER_THREADS", raising=False)
        assert _pump(threads_var="ETL_WORKER_THREADS",
                     factor_var="ETL_WORKER_QUEUE_FACTOR").threads == 1


class TestRetry:
    def test_설정_파일로_재시도를_정한다(self, monkeypatch):
        monkeypatch.setitem(cfg._FILE_CONFIG, "EMBED_RETRY_MAX_ATTEMPTS", 5)
        monkeypatch.setitem(cfg._FILE_CONFIG, "EMBED_RETRY_BACKOFF_SEC", "1,3,5")
        p = RetryPolicy.from_env()
        assert p.max_attempts == 5
        assert p.backoff_sec == (1.0, 3.0, 5.0)

    def test_설정_파일이_환경변수를_이긴다(self, monkeypatch):
        monkeypatch.setenv("EMBED_RETRY_MAX_ATTEMPTS", "9")
        monkeypatch.setitem(cfg._FILE_CONFIG, "EMBED_RETRY_MAX_ATTEMPTS", 2)
        assert RetryPolicy.from_env().max_attempts == 2

    def test_설정_파일에_목록으로_적어도_받는다(self, monkeypatch):
        """yaml 에는 `[1, 3, 5]` 로 적는 쪽이 자연스럽다."""
        monkeypatch.setitem(cfg._FILE_CONFIG, "EMBED_RETRY_BACKOFF_SEC", [1, 3, 5])
        assert RetryPolicy.from_env().backoff_sec == (1.0, 3.0, 5.0)

    def test_파일에_이상한_값이_있으면_기본값(self, monkeypatch):
        monkeypatch.setitem(cfg._FILE_CONFIG, "EMBED_RETRY_MAX_ATTEMPTS", "많이")
        monkeypatch.setitem(cfg._FILE_CONFIG, "EMBED_RETRY_BACKOFF_SEC", "조금,많이")
        p = RetryPolicy.from_env()
        assert p.max_attempts == 3
        assert p.backoff_sec == (2.0, 8.0, 30.0)
